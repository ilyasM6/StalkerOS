#!/usr/bin/python
# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Button import Button
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigSubsection, ConfigSelection, ConfigYesNo, ConfigInteger, ConfigText, getConfigListEntry
from enigma import gRGB

class SettingsScreen(Screen, ConfigListScreen):
    """Écran des paramètres du plugin Union_Stream avec configuration du player"""
    
    skin = """
    <screen name="SettingsScreen"
            position="center,center"
            size="1920,1080"
            flags="wfNoBorder"
            backgroundColor="#222222">
            
        <ePixmap position="0,0"
                 size="1920,1080"
                 pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/skins/BG_Skins.png"
                 zPosition="-1"/>
        
        <widget name="title" position="0,40" size="1920,70"
                font="Bold;55" halign="center" valign="center"
                foregroundColor="#ffffff" transparent="1" />
        
        <!-- Liste de configuration -->
        <widget name="config" position="200,150" size="1520,700"
                itemHeight="50" backgroundColor="#19181c" 
                scrollbarMode="showOnDemand" foregroundColor="white"/>
        
        <!-- Status du player -->
        <widget name="player_status" position="200,860" size="1520,40"
                font="Regular;24" halign="center" valign="center"
                foregroundColor="#00ff00" transparent="1" />
        
        <!-- Boutons d'action -->
        <widget name="btn_save" position="200,920" size="200,60"
                font="Regular;30" halign="center" valign="center"
                foregroundColor="#ffffff" backgroundColor="#2ecc71" />
        
        <widget name="btn_default" position="500,920" size="200,60"
                font="Regular;30" halign="center" valign="center"
                foregroundColor="#ffffff" backgroundColor="#3498db" />
        
        <widget name="btn_test" position="800,920" size="200,60"
                font="Regular;30" halign="center" valign="center"
                foregroundColor="#ffffff" backgroundColor="#f39c12" />
        
        <widget name="btn_cancel" position="1100,920" size="200,60"
                font="Regular;30" halign="center" valign="center"
                foregroundColor="#ffffff" backgroundColor="#e74c3c" />
        
        <widget name="key_red" position="50,980" size="100,40"
                font="Regular;24" halign="center" valign="center"
                foregroundColor="#ff0000" />
    </screen>
    """
    
    def __init__(self, session):
        Screen.__init__(self, session)
        
        # Configuration
        self.config = ConfigSubsection()
        
        # Général
        self.config.auto_start = ConfigYesNo(default=True)
        self.config.show_notifications = ConfigYesNo(default=True)
        self.config.log_level = ConfigSelection(
            choices=[
                ("0", "Aucun"),
                ("1", "Erreurs seulement"),
                ("2", "Normal"),
                ("3", "Débogage")
            ],
            default="2"
        )
        
        # Player
        self.config.player_type = ConfigSelection(
            choices=[
                ("auto", "Auto-détection"),
                ("enigma", "Player Enigma2"),
                ("serviceapp", "ServiceApp"),
                ("extvlplayer", "EXTVLPlayer"),
                ("external", "Player externe")
            ],
            default="auto"
        )
        
        self.config.preferred_player = ConfigText(default="", fixed_size=False)
        self.config.stream_timeout = ConfigInteger(default=10, limits=(5, 60))
        
        # Cache
        self.config.enable_cache = ConfigYesNo(default=True)
        self.config.cache_duration = ConfigInteger(default=3600, limits=(300, 86400))
        
        # Connexion
        self.config.timeout = ConfigInteger(default=30, limits=(5, 120))
        self.config.auto_reconnect = ConfigYesNo(default=True)
        self.config.max_retries = ConfigInteger(default=3, limits=(1, 10))
        
        # Interface
        self.config.theme = ConfigSelection(
            choices=[
                ("dark", "Sombre"),
                ("light", "Clair"),
                ("blue", "Bleu")
            ],
            default="dark"
        )
        self.config.font_size = ConfigSelection(
            choices=[
                ("small", "Petit"),
                ("medium", "Moyen"),
                ("large", "Grand")
            ],
            default="medium"
        )
        
        # Initialiser la liste de configuration
        self.list = [
            getConfigListEntry("=== GÉNÉRAL ===", None),
            getConfigListEntry("Démarrer automatiquement", self.config.auto_start),
            getConfigListEntry("Notifications", self.config.show_notifications),
            getConfigListEntry("Niveau de log", self.config.log_level),
            
            getConfigListEntry("=== PLAYER ===", None),
            getConfigListEntry("Type de player", self.config.player_type),
            getConfigListEntry("Player préféré", self.config.preferred_player),
            getConfigListEntry("Timeout stream (sec)", self.config.stream_timeout),
            
            getConfigListEntry("=== CACHE ===", None),
            getConfigListEntry("Activer le cache", self.config.enable_cache),
            getConfigListEntry("Durée cache (sec)", self.config.cache_duration),
            
            getConfigListEntry("=== CONNEXION ===", None),
            getConfigListEntry("Timeout (sec)", self.config.timeout),
            getConfigListEntry("Reconnexion auto", self.config.auto_reconnect),
            getConfigListEntry("Tentatives max", self.config.max_retries),
            
            getConfigListEntry("=== INTERFACE ===", None),
            getConfigListEntry("Thème", self.config.theme),
            getConfigListEntry("Taille police", self.config.font_size)
        ]
        
        ConfigListScreen.__init__(self, self.list, session=session)
        
        # Titre
        self["title"] = Label("🔧 Paramètres Union_Stream")
        self["player_status"] = Label("")
        
        # Boutons
        self["btn_save"] = Button("💾 Sauvegarder")
        self["btn_default"] = Button("🔄 Défaut")
        self["btn_test"] = Button("🧪 Test Player")
        self["btn_cancel"] = Button("❌ Annuler")
        self["key_red"] = Button("🔴 Quitter")
        
        # Liste des boutons
        self.buttons = [
            self["btn_save"],
            self["btn_default"],
            self["btn_test"],
            self["btn_cancel"],
            self["key_red"]
        ]
        self.button_index = 0
        
        # Vérifier le player
        self.player_available = self.check_player_availability()
        self.update_player_status()
        
        # Charger les paramètres existants
        self.load_settings()
        
        self.onLayoutFinish.append(self.initFocus)
        
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "ok": self.keyOk,
                "red": self.close,
                "cancel": self.close,
            },
            -1
        )
    
    def initFocus(self):
        """Initialise le focus"""
        self.updateFocus()
    
    def updateFocus(self):
        """Met à jour le focus visuel"""
        for i, btn in enumerate(self.buttons):
            if not btn.instance:
                continue
            if i == self.button_index:
                btn.instance.setBackgroundColor(gRGB(90, 141, 238))   # BLEU
                btn.instance.setForegroundColor(gRGB(255, 255, 255)) # BLANC
            else:
                if btn == self["btn_save"]:
                    btn.instance.setBackgroundColor(gRGB(46, 204, 113))  # VERT
                elif btn == self["btn_default"]:
                    btn.instance.setBackgroundColor(gRGB(52, 152, 219))  # BLEU
                elif btn == self["btn_test"]:
                    btn.instance.setBackgroundColor(gRGB(243, 156, 18))  # ORANGE
                elif btn == self["btn_cancel"]:
                    btn.instance.setBackgroundColor(gRGB(231, 76, 60))   # ROUGE
                else:
                    btn.instance.setBackgroundColor(gRGB(34, 34, 34))    # GRIS
                btn.instance.setForegroundColor(gRGB(200, 200, 200))
    
    def check_player_availability(self):
        """Vérifie la disponibilité des players"""
        players = {
            "enigma": False,
            "serviceapp": False,
            "extvlplayer": False
        }
        
        # Vérifier Player Enigma2
        try:
            from Screens.InfoBar import InfoBar
            from enigma import eServiceReference
            players["enigma"] = True
        except:
            players["enigma"] = False
        
        # Vérifier ServiceApp
        try:
            from Plugins.Extensions.ServiceApp.serviceapp import eServiceApp
            players["serviceapp"] = True
        except:
            players["serviceapp"] = False
        
        # Vérifier EXTVLPlayer
        try:
            # EXTVLPlayer est généralement inclus dans ServiceApp
            # Vérifier s'il est configuré
            import os
            if os.path.exists("/usr/bin/extvlplayer"):
                players["extvlplayer"] = True
        except:
            players["extvlplayer"] = False
        
        return players
    
    def update_player_status(self):
        """Met à jour le statut du player"""
        status_text = "🎬 Players disponibles: "
        
        available_players = []
        if self.player_available["enigma"]:
            available_players.append("Enigma2")
        if self.player_available["serviceapp"]:
            available_players.append("ServiceApp")
        if self.player_available["extvlplayer"]:
            available_players.append("EXTVLPlayer")
        
        if available_players:
            status_text += "✅ " + ", ".join(available_players)
        else:
            status_text += "❌ Aucun - Installez ServiceApp"
        
        self["player_status"].setText(status_text)
    
    def keyUp(self):
        """Navigation vers le haut"""
        # Si on est sur un bouton, naviguer entre boutons
        if self["config"].getCurrent() in self.buttons:
            self.button_index = max(0, self.button_index - 1)
            self.updateFocus()
        else:
            # Sinon, navigation normale dans la liste
            self["config"].instance.moveSelection(self["config"].instance.moveUp)
    
    def keyDown(self):
        """Navigation vers le bas"""
        # Si on est sur un bouton, naviguer entre boutons
        if self["config"].getCurrent() in self.buttons:
            self.button_index = min(len(self.buttons) - 1, self.button_index + 1)
            self.updateFocus()
        else:
            # Sinon, navigation normale dans la liste
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
    
    def keyLeft(self):
        """Navigation vers la gauche"""
        # Si on est sur un bouton, naviguer entre boutons
        if self["config"].getCurrent() in self.buttons:
            if self.button_index > 0:
                self.button_index -= 1
                self.updateFocus()
        else:
            # Sinon, navigation normale dans la liste
            self["config"].instance.moveSelection(self["config"].instance.moveLeft)
    
    def keyRight(self):
        """Navigation vers la droite"""
        # Si on est sur un bouton, naviguer entre boutons
        if self["config"].getCurrent() in self.buttons:
            if self.button_index < len(self.buttons) - 1:
                self.button_index += 1
                self.updateFocus()
        else:
            # Sinon, navigation normale dans la liste
            self["config"].instance.moveSelection(self["config"].instance.moveRight)
    
    def keyOk(self):
        """Action OK"""
        current_item = self["config"].getCurrent()
        
        if current_item == self["btn_save"]:
            self.save_settings()
        elif current_item == self["btn_default"]:
            self.restore_defaults()
        elif current_item == self["btn_test"]:
            self.test_player()
        elif current_item == self["btn_cancel"]:
            self.close()
        elif current_item == self["key_red"]:
            self.close()
        else:
            # Éditer l'élément de configuration
            ConfigListScreen.keyOK(self)
    
    def test_player(self):
        """Teste le player configuré"""
        try:
            test_url = "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            
            player_type = self.config.player_type.value
            
            if player_type == "auto":
                # Auto-détection
                if self.player_available["enigma"]:
                    player_type = "enigma"
                elif self.player_available["serviceapp"]:
                    player_type = "serviceapp"
                elif self.player_available["extvlplayer"]:
                    player_type = "extvlplayer"
                else:
                    player_type = "external"
            
            if player_type == "enigma":
                from Screens.InfoBar import InfoBar
                from enigma import eServiceReference
                
                infoBarInstance = InfoBar.instance
                if infoBarInstance:
                    sref = eServiceReference(4097, 0, test_url)
                    sref.setName("Test Player")
                    infoBarInstance.playService(sref)
                    message = "✅ Player Enigma2 testé"
                else:
                    message = "❌ InfoBar non disponible"
                    
            elif player_type == "serviceapp":
                try:
                    from Plugins.Extensions.ServiceApp.serviceapp import eServiceApp
                    serviceapp_instance = eServiceApp.getInstance()
                    if serviceapp_instance:
                        from enigma import eServiceReference
                        sref = eServiceReference(4097, 0, test_url)
                        sref.setName("Test ServiceApp")
                        serviceapp_instance.play(sref)
                        message = "✅ ServiceApp testé"
                    else:
                        message = "❌ ServiceApp non disponible"
                except:
                    message = "❌ ServiceApp non installé"
                    
            elif player_type == "extvlplayer":
                message = "✅ EXTVLPlayer configuré\n(Utilisé via ServiceApp)"
                
            else:  # external
                import subprocess
                try:
                    # Essayer de lancer VLC
                    subprocess.Popen(["vlc", test_url])
                    message = "✅ VLC lancé (si installé)"
                except:
                    message = "ℹ️ Copiez l'URL dans un player externe"
            
            self.session.open(
                MessageBox,
                f"🧪 Test du player:\n\n{message}",
                MessageBox.TYPE_INFO
            )
            
        except Exception as e:
            self.session.open(
                MessageBox,
                f"❌ Erreur test player:\n\n{str(e)[:100]}",
                MessageBox.TYPE_ERROR
            )
    
    def load_settings(self):
        """Charge les paramètres depuis un fichier"""
        import json
        import os
        
        settings_file = "/etc/enigma2/Union_Stream/settings.json"
        
        try:
            if os.path.exists(settings_file):
                with open(settings_file, 'r') as f:
                    settings = json.load(f)
                
                # Appliquer les paramètres
                for key in ["auto_start", "show_notifications", "log_level",
                          "player_type", "preferred_player", "stream_timeout",
                          "enable_cache", "cache_duration", "timeout",
                          "auto_reconnect", "max_retries", "theme", "font_size"]:
                    if key in settings:
                        getattr(self.config, key).value = settings[key]
                    
        except Exception as e:
            print(f"[Settings] Erreur chargement: {e}")
    
    def save_settings(self):
        """Sauvegarde les paramètres dans un fichier"""
        import json
        import os
        
        settings_file = "/etc/enigma2/Union_Stream/settings.json"
        
        try:
            # Créer le répertoire si nécessaire
            directory = os.path.dirname(settings_file)
            if not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            
            # Préparer les données
            settings = {
                "auto_start": self.config.auto_start.value,
                "show_notifications": self.config.show_notifications.value,
                "log_level": self.config.log_level.value,
                "player_type": self.config.player_type.value,
                "preferred_player": self.config.preferred_player.value,
                "stream_timeout": self.config.stream_timeout.value,
                "enable_cache": self.config.enable_cache.value,
                "cache_duration": self.config.cache_duration.value,
                "timeout": self.config.timeout.value,
                "auto_reconnect": self.config.auto_reconnect.value,
                "max_retries": self.config.max_retries.value,
                "theme": self.config.theme.value,
                "font_size": self.config.font_size.value
            }
            
            # Sauvegarder
            with open(settings_file, 'w') as f:
                json.dump(settings, f, indent=2)
            
            # Message de confirmation
            from Screens.MessageBox import MessageBox
            self.session.open(
                MessageBox,
                "✅ Paramètres sauvegardés!",
                MessageBox.TYPE_INFO
            )
            
        except Exception as e:
            print(f"[Settings] Erreur sauvegarde: {e}")
            from Screens.MessageBox import MessageBox
            self.session.open(
                MessageBox,
                f"❌ Erreur sauvegarde: {str(e)}",
                MessageBox.TYPE_ERROR
            )
    
    def restore_defaults(self):
        """Restaure les paramètres par défaut"""
        from Screens.MessageBox import MessageBox
        
        self.session.openWithCallback(
            self.confirm_restore_defaults,
            MessageBox,
            "Restaurez les paramètres par défaut?",
            MessageBox.TYPE_YESNO
        )
    
    def confirm_restore_defaults(self, result):
        """Confirme la restauration des paramètres par défaut"""
        if result:
            # Réinitialiser aux valeurs par défaut
            self.config.auto_start.value = True
            self.config.show_notifications.value = True
            self.config.log_level.value = "2"
            self.config.player_type.value = "auto"
            self.config.preferred_player.value = ""
            self.config.stream_timeout.value = 10
            self.config.enable_cache.value = True
            self.config.cache_duration.value = 3600
            self.config.timeout.value = 30
            self.config.auto_reconnect.value = True
            self.config.max_retries.value = 3
            self.config.theme.value = "dark"
            self.config.font_size.value = "medium"
            
            # Mettre à jour l'affichage
            self["config"].l.setList(self.list)
            
            # Message de confirmation
            from Screens.MessageBox import MessageBox
            self.session.open(
                MessageBox,
                "✅ Paramètres restaurés par défaut!",
                MessageBox.TYPE_INFO
            )
    
    def close(self):
        """Ferme l'écran"""
        super().close()
