#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
servers_list.py - Interface unifiée de gestion des serveurs
Remplace portals_list.py et xtream_list.py
"""

import sys
import os
import json
from datetime import datetime

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Button import Button
from enigma import gRGB

# Import du gestionnaire unifié
try:
    from .server_manager import ServerManager
    HAS_SERVER_MANAGER = True
except ImportError:
    HAS_SERVER_MANAGER = False
    print("[ServersList] ERROR: Cannot import ServerManager")

# ==================== CONSTANTES ====================
COLOR_SELECTED = 0x5a8dee
COLOR_BUTTON_GREEN = 0x2ecc71
COLOR_BUTTON_YELLOW = 0xf1c40f
COLOR_BUTTON_RED = 0xe74c3c
COLOR_BUTTON_BLUE = 0x3498db
COLOR_BUTTON_TEXT = 0x000000

class ServersListScreen(Screen):
    """
    Écran unifié de gestion des serveurs (Stalker + Xtream).
    """
    
    skin = """
<screen name="ServersListScreen" position="center,center" size="1920,1080" flags="wfNoBorder" backgroundColor="#222222">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/skins/BG_Portal.png" zPosition="-1"/>
    
    <widget name="title" position="0,40" size="1920,70" font="Bold;55" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" />
    
    <widget name="subtitle" position="0,120" size="1920,40" font="Regular;28" halign="center" valign="center" foregroundColor="#aaaaaa" transparent="1" />
    
    <widget name="server_list" position="100,200" size="1720,600" itemHeight="50" backgroundColor="#19181c" scrollbarMode="showOnDemand" foregroundColor="white" font="Regular;30" transparent="0"/>
    
    <widget name="server_info" position="100,820" size="1720,100" font="Regular;26" halign="left" valign="center" foregroundColor="#ffffff" backgroundColor="#333333" transparent="0" />
    
    <widget name="status" position="100,930" size="1720,40" font="Regular;24" halign="center" valign="center" foregroundColor="#00ff00" transparent="1" />
    
    <widget name="btn_connect" position="300,980" size="300,60" font="blend;30" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#2ecc71" transparent="0" />
    
    <widget name="btn_edit" position="600,980" size="300,60" font="blend;30" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#f1c40f" transparent="0" />
    
    <widget name="btn_delete" position="900,980" size="300,60" font="blend;30" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#e74c3c" transparent="0" />
    
    <widget name="btn_refresh" position="1200,980" size="300,60" font="blend;30" halign="center" valign="center" foregroundColor="#000000" backgroundColor="#3498db" transparent="0" />
</screen>
"""
    
    def __init__(self, session):
        Screen.__init__(self, session)
        
        # Widgets
        self["title"] = Label("🌐 Gestion des Serveurs")
        self["subtitle"] = Label("Stalker et Xtream")
        self["status"] = Label("Chargement...")
        self["server_list"] = MenuList([], enableWrapAround=True)
        self["server_info"] = Label("Sélectionnez un serveur")
        
        # Buttons - 4 seulement
        self["btn_connect"] = Button("✅ Connecter")
        self["btn_edit"] = Button("✏️ Éditer")
        self["btn_delete"] = Button("🗑️ Supprimer")
        self["btn_refresh"] = Button("🔄 Actualiser")
        
        # Gestionnaire
        if HAS_SERVER_MANAGER:
            self.manager = ServerManager()
        else:
            self.manager = None
            self["status"].setText("❌ Gestionnaire non disponible")
        
        self.servers = []
        self.current_index = 0
        self.mode = 'list'  # 'list' or 'buttons'
        self.button_index = 0
        
        # Liste des boutons pour navigation
        self.buttons = [
            self["btn_connect"],  # 0
            self["btn_edit"],     # 1
            self["btn_delete"],   # 2
            self["btn_refresh"]   # 3
        ]
        
        # Charger les serveurs
        self.load_servers()
        
        # Callbacks
        self.onLayoutFinish.append(self.initFocus)
        
        # Actions
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "ok": self.keyOk,
                "cancel": self.keyCancel,
                "red": self.keyRed,        # Supprimer (Rouge)
                "green": self.keyGreen,    # Connecter (Vert)
                "yellow": self.keyYellow,  # Éditer (Jaune)
                "blue": self.keyBlue,      # Actualiser (Bleu)
            },
            -1
        )
        
        self.log("ServersListScreen initialisé")
    
    def log(self, message):
        """Log simplifié"""
        print(f"[ServersList] {message}")
    
    def initFocus(self):
        """Initialise le focus après le rendu"""
        try:
            self.updateFocus()
            self.update_server_info()
            
            if self.manager:
                summary = self.manager.get_summary()
                self["status"].setText(
                    f"✅ {summary['total']} serveurs ({summary['stalker']} Stalker, {summary['xtream']} Xtream)"
                )
            else:
                self["status"].setText("❌ Gestionnaire non disponible")
                
        except Exception as e:
            self.log(f"Erreur initFocus: {e}")
            self["status"].setText(f"❌ Erreur: {str(e)[:30]}")
    
    def load_servers(self):
        """Charge la liste des serveurs"""
        try:
            if not self.manager:
                self["server_list"].setList(["❌ Gestionnaire non disponible"])
                return
            
            self.servers = self.manager.get_servers()
            
            display_list = []
            for i, server in enumerate(self.servers):
                name = server.get('name', f'Serveur {i+1}')
                server_type = server.get('type', 'stalker')
                active = server.get('active', False)
                tested = server.get('tested', False)
                
                # Icônes
                type_icon = "📡 " if server_type == "stalker" else "🔗 "
                status_icon = "🟢 " if active else "⚪ "
                test_icon = "✅ " if tested and "success" in str(server.get('test_result', '')).lower() else "⚠️ " if tested else "❓ "
                
                display_text = f"{status_icon}{type_icon}{test_icon}{name}"
                display_list.append(display_text)
            
            if display_list:
                self["server_list"].setList(display_list)
                if self.servers:
                    self.current_index = 0
                    self["server_list"].moveToIndex(0)
            else:
                self["server_list"].setList(["Aucun serveur configuré"])
                self["status"].setText("⚠️ Ajoutez un serveur avec le bouton '➕ Ajouter'")
                
        except Exception as e:
            self.log(f"Erreur load_servers: {e}")
            self["server_list"].setList([f"Erreur: {str(e)[:30]}"])
    
    def updateFocus(self):
        """Met à jour le focus visuel"""
        try:
            if self.mode == 'list':
                # Mode liste: désélectionner tous les boutons
                self.deselect_all_buttons()
                
                # Activer la sélection dans la liste
                if self.servers and self.current_index < len(self.servers):
                    self["server_list"].moveToIndex(self.current_index)
                
            else:  # Mode boutons
                # Mettre en surbrillance le bouton sélectionné
                self.highlight_selected_button()
                
        except Exception as e:
            self.log(f"Erreur updateFocus: {e}")
    
    def deselect_all_buttons(self):
        """Désélectionne visuellement tous les boutons"""
        try:
            for i, btn in enumerate(self.buttons):
                if btn.instance:
                    # Couleurs par défaut selon le type de bouton
                    if btn == self["btn_connect"]:
                        bg_color = gRGB(COLOR_BUTTON_GREEN)  # Vert
                    elif btn == self["btn_edit"]:
                        bg_color = gRGB(COLOR_BUTTON_YELLOW) # Jaune
                    elif btn == self["btn_delete"]:
                        bg_color = gRGB(COLOR_BUTTON_RED)    # Rouge
                    elif btn == self["btn_refresh"]:
                        bg_color = gRGB(COLOR_BUTTON_BLUE)   # Bleu
                    else:
                        bg_color = gRGB(34, 34, 34)          # Gris foncé
                    
                    # Texte en noir
                    text_color = gRGB(COLOR_BUTTON_TEXT)
                    
                    btn.instance.setBackgroundColor(bg_color)
                    btn.instance.setForegroundColor(text_color)
                    
        except Exception as e:
            self.log(f"Erreur deselect_all_buttons: {e}")
    
    def highlight_selected_button(self):
        """Met en surbrillance le bouton sélectionné"""
        try:
            for i, btn in enumerate(self.buttons):
                if btn.instance:
                    if i == self.button_index:
                        # Bouton sélectionné: fond bleu clair, texte noir
                        btn.instance.setBackgroundColor(gRGB(90, 141, 238))
                        btn.instance.setForegroundColor(gRGB(COLOR_BUTTON_TEXT))
                    else:
                        # Bouton non sélectionné: appeler deselect_all_buttons
                        self.deselect_all_buttons()
                        
        except Exception as e:
            self.log(f"Erreur highlight_selected_button: {e}")
    
    def get_current_server(self):
        """Retourne le serveur actuellement sélectionné"""
        if not self.servers or self.current_index >= len(self.servers):
            return None
        return self.servers[self.current_index]
    
    def update_server_info(self):
        """Met à jour les informations du serveur sélectionné"""
        try:
            server = self.get_current_server()
            
            if not server:
                self["server_info"].setText("Aucun serveur sélectionné")
                return
            
            # Extraire les informations
            name = server.get('name', 'N/A')
            host = server.get('host', 'N/A')
            server_type = server.get('type', 'stalker')
            active = server.get('active', False)
            tested = server.get('tested', False)
            test_result = server.get('test_result', '')
            
            # Tronquer l'URL si trop longue
            if len(host) > 40:
                host_display = host[:37] + "..."
            else:
                host_display = host
            
            # Informations supplémentaires selon le type
            if server_type == 'stalker':
                mac = server.get('mac', 'N/A')
                extra_info = f"MAC: {mac}"
            else:  # xtream
                username = server.get('username', 'N/A')
                if len(username) > 15:
                    username = username[:12] + "..."
                extra_info = f"User: {username}"
            
            # Formater le texte d'information
            type_text = "Stalker" if server_type == "stalker" else "Xtream"
            status_text = "🟢 ACTIF" if active else "⚪ INACTIF"
            test_text = "✅ Testé" if tested else "⚠️ Non testé"
            
            info_lines = [
                f"📡 {name}",
                f"🌐 {host_display}",
                f"📊 {type_text}",
                f"{status_text}",
                f"{test_text}"
            ]
            
            info_text = " | ".join(info_lines)
            self["server_info"].setText(info_text)
            
        except Exception as e:
            self.log(f"Erreur update_server_info: {e}")
            self["server_info"].setText("Erreur d'affichage")
    
    # ==================== NAVIGATION ====================
    
    def keyUp(self):
        """Touche Haut"""
        try:
            if self.mode == 'list':
                if self.servers:
                    # Déplacer vers le haut dans la liste
                    if self.current_index > 0:
                        self.current_index -= 1
                    else:
                        self.current_index = len(self.servers) - 1  # Boucler
                    
                    self["server_list"].up()
                    self.update_server_info()
                    self.log(f"Navigation ↑ - Index: {self.current_index}")
            
            else:  # Mode boutons
                # Retourner en mode liste
                self.mode = 'list'
                self.updateFocus()
                self.log("Retour en mode liste")
                
        except Exception as e:
            self.log(f"Erreur keyUp: {e}")
    
    def keyDown(self):
        """Touche Bas"""
        try:
            if self.mode == 'list':
                if self.servers:
                    # Déplacer vers le bas dans la liste
                    if self.current_index < len(self.servers) - 1:
                        self.current_index += 1
                    else:
                        self.current_index = 0  # Boucler
                    
                    self["server_list"].down()
                    self.update_server_info()
                    self.log(f"Navigation ↓ - Index: {self.current_index}")
            
            else:  # Mode boutons
                # Retourner en mode liste
                self.mode = 'list'
                self.updateFocus()
                self.log("Retour en mode liste")
                
        except Exception as e:
            self.log(f"Erreur keyDown: {e}")
    
    def keyLeft(self):
        """Touche Gauche"""
        try:
            if self.mode == 'list':
                # Passer en mode boutons (dernier bouton)
                self.mode = 'buttons'
                self.button_index = len(self.buttons) - 1  # Dernier bouton
                self.updateFocus()
                self.log(f"Mode boutons ← - Bouton: {self.button_index}")
            
            else:  # Mode boutons
                # Déplacer vers la gauche
                if self.button_index > 0:
                    self.button_index -= 1
                else:
                    self.button_index = len(self.buttons) - 1  # Boucler
                
                self.updateFocus()
                self.log(f"Navigation boutons ← - Bouton: {self.button_index}")
                
        except Exception as e:
            self.log(f"Erreur keyLeft: {e}")
    
    def keyRight(self):
        """Touche Droite"""
        try:
            if self.mode == 'list':
                # Passer en mode boutons (premier bouton)
                self.mode = 'buttons'
                self.button_index = 0  # Premier bouton
                self.updateFocus()
                self.log(f"Mode boutons → - Bouton: {self.button_index}")
            
            else:  # Mode boutons
                # Déplacer vers la droite
                if self.button_index < len(self.buttons) - 1:
                    self.button_index += 1
                else:
                    self.button_index = 0  # Boucler
                
                self.updateFocus()
                self.log(f"Navigation boutons → - Bouton: {self.button_index}")
                
        except Exception as e:
            self.log(f"Erreur keyRight: {e}")
    
    def keyOk(self):
        """Touche OK"""
        try:
            if self.mode == 'list':
                # Connecter au serveur sélectionné
                self.connect_server()
            
            else:  # Mode boutons
                # Exécuter l'action du bouton sélectionné
                self.execute_button_action()
                
        except Exception as e:
            self.log(f"Erreur keyOk: {e}")
            self.show_message(f"Erreur: {str(e)[:50]}", "ERROR")
    
    def keyCancel(self):
        """Touche Annuler"""
        self.log("Fermeture (Annuler)")
        self.close()
    
    def keyGreen(self):
        """Bouton Vert - Connecter"""
        self.log("Action: Connecter (Vert)")
        self.connect_server()
    
    def keyYellow(self):
        """Bouton Jaune - Éditer"""
        self.log("Action: Éditer (Jaune)")
        self.edit_server()
    
    def keyBlue(self):
        """Bouton Bleu - Actualiser"""
        self.log("Action: Actualiser (Bleu)")
        self.refresh_servers()
    
    def keyRed(self):
        """Bouton Rouge - Supprimer"""
        self.log("Action: Supprimer (Rouge)")
        self.delete_server()
    
    def execute_button_action(self):
        """Exécute l'action du bouton sélectionné"""
        try:
            if self.button_index == 0:  # Connecter
                self.connect_server()
            
            elif self.button_index == 1:  # Éditer
                self.edit_server()
            
            elif self.button_index == 2:  # Supprimer
                self.delete_server()
            
            elif self.button_index == 3:  # Actualiser
                self.refresh_servers()
                
        except Exception as e:
            self.log(f"Erreur execute_button_action: {e}")
            self.show_message(f"Erreur d'action: {str(e)[:50]}", "ERROR")
    
    def connect_server(self):
        """Connecte au serveur sélectionné"""
        try:
            server = self.get_current_server()
            
            if not server:
                self.show_message("Aucun serveur sélectionné", "ERROR")
                return
            
            if not self.manager:
                self.show_message("Gestionnaire non disponible", "ERROR")
                return
            
            server_name = server.get('name', 'Serveur inconnu')
            
            self["status"].setText(f"🔗 Connexion à {server_name}...")
            
            # Activer le serveur via le gestionnaire
            result = self.manager.set_active_server(self.current_index)
            
            if result['success']:
                # Recharger la liste
                self.load_servers()
                self.update_server_info()
                
                # Afficher message de succès
                self.show_message(
                    f"✅ Serveur activé:\n\n{server_name}\n\n{result.get('message', '')}",
                    "INFO"
                )
                
                self["status"].setText(f"✅ {server_name} activé")
                self.log(f"Connecté à: {server_name}")
                
            else:
                self.show_message(f"❌ Erreur: {result['message']}", "ERROR")
                self["status"].setText(f"❌ Échec connexion")
                
        except Exception as e:
            self.log(f"Erreur connect_server: {e}")
            self.show_message(f"❌ Erreur connexion: {str(e)[:50]}", "ERROR")
            self["status"].setText("❌ Erreur")
    
    def edit_server(self):
        """Édite le serveur sélectionné"""
        try:
            server = self.get_current_server()
            
            if not server:
                self.show_message("Aucun serveur sélectionné", "ERROR")
                return
            
            server_name = server.get('name', 'Serveur inconnu')
            server_type = server.get('type', 'stalker')
            
            self.log(f"Édition du serveur: {server_name} ({server_type})")
            
            # Menu pour choisir l'action d'édition
            options = [
                ("✏️ Éditer les paramètres", "edit_params"),
                ("📝 Renommer le serveur", "rename")
            ]
            
            self.session.openWithCallback(
                lambda result: self.on_edit_action_selected(result, server_type),
                ChoiceBox,
                title=f"Édition: {server_name}",
                list=options
            )
            
        except Exception as e:
            self.log(f"Erreur edit_server: {e}")
            self.show_message(f"Erreur d'édition: {str(e)[:50]}", "ERROR")
    
    def on_edit_action_selected(self, result, server_type):
        """Gère la sélection d'action d'édition"""
        if result:
            action = result[1]
            
            if action == "edit_params":
                # Édition des paramètres
                try:
                    if server_type == 'stalker':
                        # Importer l'écran d'édition Stalker
                        try:
                            from .configuration import ConfigurationScreen
                            
                            # Ouvrir en mode édition
                            self.session.openWithCallback(
                                self.on_edit_complete,
                                ConfigurationScreen,
                                edit_index=self.current_index
                            )
                            
                        except ImportError as e:
                            self.log(f"ImportError configuration: {e}")
                            self.show_message("Écran d'édition Stalker non disponible", "ERROR")
                    
                    else:  # xtream
                        # Importer l'écran d'édition Xtream
                        try:
                            from .xtream_edit import XtreamEditScreen
                            
                            server = self.get_current_server()
                            self.session.openWithCallback(
                                self.on_edit_complete,
                                XtreamEditScreen,
                                server_data=server,
                                edit_index=self.current_index
                            )
                            
                        except ImportError:
                            # Fallback
                            self.show_message(
                                "Écran d'édition Xtream sera disponible prochainement",
                                "INFO"
                            )
                            
                except Exception as e:
                    self.log(f"Erreur edit_params: {e}")
                    self.show_message(f"Erreur: {str(e)[:50]}", "ERROR")
            
            elif action == "rename":
                # Renommer le serveur
                self.rename_server()
    
    def rename_server(self):
        """Renomme le serveur sélectionné"""
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            
            server = self.get_current_server()
            if not server:
                return
            
            old_name = server.get('name', '')
            
            # Ouvrir le clavier virtuel
            self.session.openWithCallback(
                lambda new_name: self.on_rename_completed(new_name),
                VirtualKeyBoard,
                title=f"Renommer le serveur:\nAncien nom: {old_name}",
                text=old_name
            )
            
        except ImportError:
            self.show_message("Clavier virtuel non disponible", "ERROR")
        except Exception as e:
            self.log(f"Erreur rename_server: {e}")
            self.show_message(f"Erreur: {str(e)[:50]}", "ERROR")
    
    def on_rename_completed(self, new_name):
        """Callback après renommage"""
        if new_name:
            try:
                if not self.manager:
                    return
                
                # Mettre à jour le nom
                server = self.get_current_server()
                if not server:
                    return
                
                old_name = server.get('name', '')
                server['name'] = new_name
                
                # Sauvegarder via le gestionnaire
                result = self.manager.update_server(self.current_index, server)
                
                if result['success']:
                    # Recharger l'affichage
                    self.load_servers()
                    self.update_server_info()
                    self.show_message(
                        f"✅ Serveur renommé:\n\n{old_name}\n→\n{new_name}",
                        "INFO"
                    )
                else:
                    self.show_message(f"❌ Erreur: {result['message']}", "ERROR")
                    
            except Exception as e:
                self.log(f"Erreur on_rename_completed: {e}")
                self.show_message(f"Erreur: {str(e)[:50]}", "ERROR")
    
    def delete_server(self):
        """Supprime le serveur sélectionné"""
        try:
            server = self.get_current_server()
            
            if not server:
                self.show_message("Aucun serveur sélectionné", "ERROR")
                return
            
            if not self.manager:
                self.show_message("Gestionnaire non disponible", "ERROR")
                return
            
            server_name = server.get('name', 'Serveur inconnu')
            is_active = server.get('active', False)
            
            # Message de confirmation
            message = f"🗑️ SUPPRIMER le serveur?\n\nNom: {server_name}\n\n"
            
            if is_active:
                message += "⚠️ ATTENTION: Ce serveur est ACTIF!\n\n"
            
            message += "Cette action est irréversible!"
            
            self.session.openWithCallback(
                lambda result: self.confirm_delete(result),
                MessageBox,
                message,
                MessageBox.TYPE_YESNO
            )
            
        except Exception as e:
            self.log(f"Erreur delete_server: {e}")
            self.show_message(f"Erreur de suppression: {str(e)[:50]}", "ERROR")
    
    def confirm_delete(self, result):
        """Confirme la suppression"""
        if result:
            try:
                server = self.get_current_server()
                if not server:
                    return
                
                server_name = server.get('name', 'Serveur inconnu')
                server_index = self.current_index
                
                # Supprimer via le gestionnaire
                delete_result = self.manager.delete_server(server_index)
                
                if delete_result['success']:
                    # Ajuster l'index courant
                    if server_index < self.current_index:
                        self.current_index -= 1
                    elif server_index == self.current_index:
                        self.current_index = max(0, len(self.manager.get_servers()) - 1)
                    
                    # Recharger
                    self.load_servers()
                    self.update_server_info()
                    
                    # Message de confirmation
                    self.show_message(delete_result['message'], "INFO")
                    
                    # Mettre à jour le statut
                    summary = self.manager.get_summary()
                    self["status"].setText(
                        f"✅ {summary['total']} serveurs ({summary['stalker']} Stalker, {summary['xtream']} Xtream)"
                    )
                    
                    self.log(f"Supprimé: {server_name}")
                    
                else:
                    self.show_message(f"❌ {delete_result['message']}", "ERROR")
                    
            except Exception as e:
                self.log(f"Erreur confirm_delete: {e}")
                self.show_message(f"❌ Erreur suppression: {str(e)[:50]}", "ERROR")
    
    def refresh_servers(self):
        """Actualise la liste des serveurs"""
        try:
            self["status"].setText("🔄 Actualisation en cours...")
            self.log("Actualisation de la liste des serveurs")
            
            # Recharger la liste
            self.load_servers()
            self.update_server_info()
            
            if self.manager:
                summary = self.manager.get_summary()
                self["status"].setText(
                    f"✅ {summary['total']} serveurs ({summary['stalker']} Stalker, {summary['xtream']} Xtream)"
                )
            else:
                self["status"].setText("❌ Gestionnaire non disponible")
                
            self.show_message("✅ Liste des serveurs actualisée", "INFO")
            
        except Exception as e:
            self.log(f"Erreur refresh_servers: {e}")
            self["status"].setText("❌ Erreur d'actualisation")
            self.show_message(f"❌ Erreur d'actualisation: {str(e)[:50]}", "ERROR")
    
    def on_edit_complete(self, result=None):
        """
        Callback après édition/ajout d'un serveur.
        
        Args:
            result: Résultat de l'opération
        """
        self.log("Opération terminée, rechargement...")
        
        # Recharger les serveurs
        if self.manager:
            self.servers = self.manager.get_servers()
            self.load_servers()
            self.update_server_info()
            
            # Mettre à jour le statut
            summary = self.manager.get_summary()
            self["status"].setText(
                f"✅ {summary['total']} serveurs ({summary['stalker']} Stalker, {summary['xtream']} Xtream)"
            )
    
    def show_message(self, message, msg_type="INFO"):
        """
        Affiche un message à l'utilisateur.
        
        Args:
            message: Message à afficher
            msg_type: Type de message ('INFO' ou 'ERROR')
        """
        try:
            if msg_type == "ERROR":
                self.session.open(
                    MessageBox,
                    message,
                    MessageBox.TYPE_ERROR,
                    timeout=5
                )
            else:
                self.session.open(
                    MessageBox,
                    message,
                    MessageBox.TYPE_INFO,
                    timeout=5
                )
                
        except Exception as e:
            self.log(f"Erreur show_message: {e}")
            print(f"Message ({msg_type}): {message}")
    
    def keyMenu(self):
        """Touche Menu pour ajouter un serveur"""
        try:
            # Menu de choix du type de serveur
            options = [
                ("📡 Ajouter un serveur Stalker", "stalker"),
                ("🔗 Ajouter un serveur Xtream", "xtream")
            ]
            
            self.session.openWithCallback(
                self.on_add_type_selected,
                ChoiceBox,
                title="Type de serveur à ajouter",
                list=options
            )
            
        except Exception as e:
            self.log(f"Erreur keyMenu: {e}")
            self.show_message(f"Erreur d'ajout: {str(e)[:50]}", "ERROR")
    
    def on_add_type_selected(self, result):
        """Callback pour le type de serveur à ajouter"""
        if result:
            server_type = result[1]
            
            try:
                if server_type == "stalker":
                    # Importer l'écran d'ajout Stalker
                    try:
                        from .configuration import ConfigurationScreen
                        
                        # Ouvrir en mode ajout (pas d'edit_index)
                        self.session.openWithCallback(
                            self.on_edit_complete,
                            ConfigurationScreen,
                            edit_index=None
                        )
                        
                    except ImportError as e:
                        self.log(f"ImportError configuration: {e}")
                        self.show_message("Écran d'ajout Stalker non disponible", "ERROR")
                
                else:  # xtream
                    # Importer l'écran d'ajout Xtream
                    try:
                        from .xtream_edit import XtreamEditScreen
                        
                        # Ouvrir en mode ajout
                        self.session.openWithCallback(
                            self.on_edit_complete,
                            XtreamEditScreen,
                            server_data=None,
                            edit_index=None
                        )
                        
                    except ImportError:
                        # Fallback: message d'information
                        self.show_message(
                            "Écran d'ajout Xtream sera disponible prochainement\n\n"
                            "Ajoutez un serveur Stalker pour l'instant.",
                            "INFO"
                        )
                        
            except Exception as e:
                self.log(f"Erreur on_add_type_selected: {e}")
                self.show_message(f"Erreur: {str(e)[:50]}", "ERROR")
    
    def close(self):
        """Ferme l'écran"""
        self.log("Fermeture de ServersListScreen")
        self["status"].setText("👋 Fermeture...")
        super().close()


# Test unitaire
if __name__ == "__main__":
    print("=== Test de ServersListScreen ===")
    
    # Tester l'import
    try:
        from server_manager import ServerManager
        manager = ServerManager()
        print(f"✅ ServerManager chargé: {len(manager.get_servers())} serveurs")
    except ImportError as e:
        print(f"❌ ImportError: {e}")
    
    print("=== Test terminé ===")
