#!/usr/bin/python
# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.config import ConfigSubsection, ConfigText, ConfigPassword, getConfigListEntry
from Components.Label import Label
from Components.Button import Button
from enigma import eListboxPythonConfigContent, eListbox, gFont
import json
import os
import re
from datetime import datetime

class ConfigurationScreen(Screen):
    """Configuration screen for server management - Version 1920x1080"""
    
    skin = """
        <screen position="center,center" size="1920,1080" title="Union_Stream Configuration">
            <!-- Background Image -->
            <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/skins/BG_Portal.png" zPosition="-1"/>
            
            <!-- Title and subtitle -->
            <widget name="title" position="300,80" size="1320,80" font="Bold;48" halign="center" valign="center" foregroundColor="white"/>
            <widget name="subtitle" position="300,180" size="1320,40" font="Regular;32" halign="center" valign="center" foregroundColor="#CCCCCC"/>
            
            <!-- Left side: Server Information -->
            <eLabel position="100,250" size="800,600" backgroundColor="#19181c" transparent="0" zPosition="1"/>
            <widget name="server_info" position="120,270" size="760,640" font="Regular;32" backgroundColor="#19181c" transparent="1" foregroundColor="white" valign="top" halign="left"/>
            
            <!-- Right side: Configuration fields -->
            <eLabel position="940,250" size="880,600" backgroundColor="#19181c" transparent="0" zPosition="1"/>
            <widget name="config" position="960,270" size="840,500" itemHeight="65" backgroundColor="#19181c" scrollbarMode="showOnDemand" foregroundColor="white" zPosition="2"/>
            
            <!-- Buttons at bottom - seulement 3 boutons maintenant -->
            <widget name="btn_save" position="440,920" size="340,80" font="Bold;32" halign="center" valign="center" backgroundColor="#006400" foregroundColor="white"/>
            <widget name="btn_delete" position="840,920" size="340,80" font="Bold;32" halign="center" valign="center" backgroundColor="#ff0000" foregroundColor="white"/>
            <widget name="btn_next" position="1240,920" size="340,80" font="Bold;32" halign="center" valign="center" backgroundColor="#ffff00" foregroundColor="black"/>
        </screen>
    """

    def __init__(self, session, edit_index=None):
        """Initialize the configuration screen with PortalManager"""
        Screen.__init__(self, session)
        
        # EDIT MODE: Si on vient de portals_list.py
        self.edit_index = edit_index
        self.edit_mode = edit_index is not None
        
        # Utiliser PortalManager comme source unique
        try:
            from .server_manager import ServerManager
            self.manager = ServerManager()
            self.servers = self.manager.get_servers('stalker')  # Seulement Stalker
        except ImportError as e:
            self.manager = None
            self.servers = []
            print(f"[Configuration] PortalManager import error: {e}")
        
        # Titre
        title_text = "✏️ Éditer Serveur" if self.edit_mode else "➕ Ajouter Serveur"
        self["title"] = Label(title_text)
        self["subtitle"] = Label("Configurez votre serveur Stalker / Xtream")
        
        # Informations serveur
        self["server_info"] = Label("")
        
        # Configuration fields - 5 champs maintenant
        self.config = ConfigSubsection()
        self.config.server_name = ConfigText(default="myserver", fixed_size=False)
        self.config.server_host = ConfigText(default="http://myserver.com:8080", fixed_size=False)
        self.config.server_mac = ConfigText(default="00:1A:79:AA:1B:CD", fixed_size=False)
        self.config.server_user = ConfigText(default="user", fixed_size=False)
        self.config.server_pass = ConfigPassword(default="pass", fixed_size=False)
        
        # Liste de configuration
        self.list = [
            getConfigListEntry("📛 Server Name", self.config.server_name),
            getConfigListEntry("🌐 Server URL", self.config.server_host),
            getConfigListEntry("🔑 MAC Adress", self.config.server_mac),
            getConfigListEntry("👤 Username", self.config.server_user),
            getConfigListEntry("🔒 Password", self.config.server_pass)
        ]
        
        # Créer manuellement le ConfigList
        self["config"] = ConfigList(self.list)
        
        # Boutons - seulement 3 maintenant
        self["btn_save"] = Button("💾 Save" if self.edit_mode else "➕ Add")
        self["btn_delete"] = Button("🗑️ Delete")
        self["btn_next"] = Button("↔️ Next")
        
        # Navigation horizontale (gauche/droite entre éléments)
        self.current_config_index = 0  # Index dans la liste config
        self.current_button_index = 0  # 0=save, 1=delete, 2=next
        self.in_config_mode = True     # True=on est dans la config, False=on est dans les boutons
        
        self.buttons = [
            self["btn_save"],
            self["btn_delete"],
            self["btn_next"]
        ]
        
        # Charger les données si en mode édition
        if self.edit_mode and self.edit_index is not None and self.edit_index < len(self.servers):
            self.load_server_data(self.edit_index)
        else:
            self.update_server_info("Nouveau serveur. Remplissez les champs.")
        
        # Actions - SUPPRIMER keyBlue car pas de bouton bleu
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions"], {
            "red": self.keyRed,
            "green": self.keyGreen,
            "yellow": self.keyYellow,
            # "blue": self.keyBlue,  # SUPPRIMÉ - pas de bouton bleu
            "ok": self.keyOk,
            "cancel": self.keyCancel,
            "up": self.keyUp,
            "down": self.keyDown,
            "left": self.keyLeft,
            "right": self.keyRight,
        }, -2)
        
        # Initialiser après le rendu
        self.onLayoutFinish.append(self.initFocus)
        
        print(f"[Configuration] Screen initialisé (mode: {'édition' if self.edit_mode else 'ajout'})")
    
    def initFocus(self):
        """Initialise le focus après le rendu"""
        self.updateFocus()
    
    def updateFocus(self):
        """Met à jour le focus visuel"""
        try:
            if self.in_config_mode:
                # Focus sur la liste de configuration
                self["config"].instance.setSelectionEnable(True)
                # Mettre à jour la sélection dans la liste
                self["config"].setCurrentIndex(self.current_config_index)
                # Désélectionner les boutons
                for btn in self.buttons:
                    if hasattr(btn, 'instance') and btn.instance:
                        # Couleurs normales
                        if btn == self["btn_save"]:
                            btn.instance.setBackgroundColorNum(0x006400)  # Vert
                        elif btn == self["btn_delete"]:
                            btn.instance.setBackgroundColorNum(0xff0000)  # Rouge
                        elif btn == self["btn_next"]:
                            btn.instance.setBackgroundColorNum(0xffff00)  # Jaune
            else:
                # Focus sur les boutons
                self["config"].instance.setSelectionEnable(False)
                
                for i, btn in enumerate(self.buttons):
                    if hasattr(btn, 'instance') and btn.instance:
                        if i == self.current_button_index:
                            # Bouton sélectionné - surbrillance
                            btn.instance.setBackgroundColorNum(0x5a8dee)  # Bleu clair
                        else:
                            # Couleurs normales
                            if btn == self["btn_save"]:
                                btn.instance.setBackgroundColorNum(0x006400)  # Vert
                            elif btn == self["btn_delete"]:
                                btn.instance.setBackgroundColorNum(0xff0000)  # Rouge
                            elif btn == self["btn_next"]:
                                btn.instance.setBackgroundColorNum(0xffff00)  # Jaune
        except Exception as e:
            print(f"[Configuration] Erreur updateFocus: {e}")
    
    def load_server_data(self, index):
        """Charge les données d'un serveur via PortalManager"""
        try:
            if not self.manager or index >= len(self.servers):
                return
            
            server = self.servers[index]
            self.config.server_name.value = server.get('name', '')
            self.config.server_host.value = server.get('host', '')
            self.config.server_mac.value = server.get('mac', '')
            self.config.server_user.value = server.get('user', '')
            self.config.server_pass.value = server.get('password', '')
            self.current_index = index
            
            # Mettre à jour la liste
            self["config"].setList(self.list)
            self.update_server_info()
            
            print(f"[Configuration] Chargé serveur {index}: {server.get('name')}")
            
        except Exception as e:
            print(f"[Configuration] Erreur chargement serveur: {e}")
    
    def update_server_info(self, message=None):
        """Met à jour les informations affichées"""
        try:
            if message:
                info_text = message
            elif self.servers and 0 <= self.current_index < len(self.servers):
                server = self.servers[self.current_index]
                info_text = f"📋 INFORMATIONS SERVEUR\n\n"
                info_text += f"📛 Nom: {server.get('name', 'N/A')}\n\n"
                
                host = server.get('host', 'N/A')
                if len(host) > 50:
                    host = host[:47] + "..."
                info_text += f"🌐 URL: {host}\n\n"
                
                info_text += f"🔑 MAC: {server.get('mac', 'N/A')}\n\n"
                
                user = server.get('user', 'N/A')
                if user:
                    info_text += f"👤 Utilisateur: {user}\n\n"
                
                passwd = server.get('password', '')
                if passwd:
                    info_text += f"🔒 Mot de passe: {'*' * min(len(passwd), 8)}\n\n"
                
                info_text += f"📊 Statut: {'🟢 ACTIF' if server.get('active', False) else '⚪ INACTIF'}\n\n"
                info_text += f"🔢 Index: {self.current_index + 1}/{len(self.servers)}"
            elif self.servers and len(self.servers) > 0:
                self.current_index = 0
                self.load_server_data(0)
                return
            else:
                info_text = "📋 INFORMATIONS SERVEUR\n\nAucun serveur configuré\n\nAjoutez un serveur avec le formulaire"
            
            self["server_info"].setText(info_text)
        except Exception as e:
            print(f"[Configuration] Erreur update_server_info: {e}")
    
    # ==================== NAVIGATION CLAVIER MODIFIÉE ====================
    
    def keyUp(self):
        """Navigation vers le haut DANS la configuration"""
        if self.in_config_mode:
            if self.current_config_index > 0:
                self.current_config_index -= 1
                self.updateFocus()
    
    def keyDown(self):
        """Navigation vers le bas DANS la configuration"""
        if self.in_config_mode:
            if self.current_config_index < len(self.list) - 1:
                self.current_config_index += 1
                self.updateFocus()
    
    def keyLeft(self):
        """Navigation vers la gauche - Change de section"""
        if self.in_config_mode:
            # Passer de la config aux boutons
            self.in_config_mode = False
            self.current_button_index = 0
        else:
            # Navigation entre boutons
            if self.current_button_index > 0:
                self.current_button_index -= 1
        self.updateFocus()
    
    def keyRight(self):
        """Navigation vers la droite - Change de section"""
        if self.in_config_mode:
            # Rester dans la config, navigation dans les champs
            self["config"].instance.moveSelection(self["config"].instance.moveRight)
        else:
            # Navigation entre boutons
            if self.current_button_index < len(self.buttons) - 1:
                self.current_button_index += 1
            else:
                # Retourner à la config
                self.in_config_mode = True
                self.current_config_index = 0
        self.updateFocus()
    
    def keyOk(self):
        """Action OK"""
        if self.in_config_mode:
            # Éditer l'élément de config sélectionné
            if self.current_config_index < len(self.list):
                self["config"].setCurrentIndex(self.current_config_index)
                self["config"].handleKey(0)  # Code pour "select"
        else:
            # Action sur le bouton sélectionné
            if self.current_button_index == 0:  # Sauvegarder/Ajouter
                self.save_server()
            elif self.current_button_index == 1:  # Supprimer
                self.delete_server()
            elif self.current_button_index == 2:  # Changer
                self.next_server()
    
    def keyGreen(self):
        """Bouton Vert = Sauvegarder/Ajouter"""
        self.save_server()
    
    def keyRed(self):
        """Bouton Rouge = Supprimer"""
        self.delete_server()
    
    def keyYellow(self):
        """Bouton Jaune = Changer de serveur"""
        self.next_server()
    
    def keyCancel(self):
        """Bouton Annuler = Quitter"""
        self.close()
    
    # ==================== ACTIONS ====================
    
    def save_server(self):
        """Sauvegarde un serveur via PortalManager"""
        if not self.manager:
            self.session.open(MessageBox, "❌ PortalManager non disponible", MessageBox.TYPE_ERROR)
            return
        
        name = self.config.server_name.value.strip()
        host = self.config.server_host.value.strip()
        mac = self.config.server_mac.value.strip()
        user = self.config.server_user.value.strip()
        password = self.config.server_pass.value.strip()
        
        print(f"[Configuration] Sauvegarde - Nom: '{name}', Host: '{host}', MAC: '{mac}', User: '{user}'")
        
        # Validation
        validation_errors = []
        
        if not name:
            validation_errors.append("Le nom du serveur est requis")
        
        if not host:
            validation_errors.append("L'URL du serveur est requise")
        elif not host.startswith(('http://', 'https://')):
            validation_errors.append("L'URL doit commencer par http:// ou https://")
        
        if not mac:
            validation_errors.append("L'adresse MAC est requise")
        
        if validation_errors:
            error_message = "❌ Veuillez corriger:\n\n" + "\n".join(f"• {error}" for error in validation_errors)
            self.session.open(MessageBox, error_message, MessageBox.TYPE_ERROR)
            return
        
        try:
            # Formater l'adresse MAC
            formatted_mac = self.manager.format_mac_address(mac)
            
            if not self.manager.validate_mac_address(formatted_mac):
                self.session.open(
                    MessageBox,
                    "❌ Adresse MAC invalide!\n\nFormat: 00:1A:79:XX:XX:XX",
                    MessageBox.TYPE_ERROR
                )
                return
            
            if self.edit_mode and 0 <= self.current_index < len(self.servers):
                # MODE ÉDITION
                result = self.manager.update_portal(
                    index=self.current_index,
                    name=name,
                    host=host,
                    mac=formatted_mac,
                    user=user,
                    password=password,
                    test_connection=True
                )
                
                if result['success']:
                    self.servers = self.manager.get_portals()
                    message = f"✅ Serveur '{name}' mis à jour!\n\n{result.get('message', 'Succès')}"
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
                    
                    # Retour à l'écran précédent
                    self.close(True)
                else:
                    self.session.open(
                        MessageBox,
                        f"❌ Erreur:\n\n{result.get('message', 'Erreur inconnue')}",
                        MessageBox.TYPE_ERROR
                    )
                    
            else:
                # MODE AJOUT
                result = self.manager.add_portal(
                    name=name,
                    host=host,
                    mac=formatted_mac,
                    user=user,
                    password=password,
                    test_connection=True,
                    timeout=30
                )
                
                if result['success']:
                    self.servers = self.manager.get_portals()
                    self.current_index = len(self.servers) - 1
                    self.load_server_data(self.current_index)
                    
                    message = f"✅ Serveur '{name}' ajouté!\n\n{result.get('message', 'Succès')}"
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
                else:
                    self.session.open(
                        MessageBox,
                        f"❌ Erreur:\n\n{result.get('message', 'Erreur inconnue')}",
                        MessageBox.TYPE_ERROR
                    )
            
        except Exception as e:
            print(f"[Configuration] Erreur sauvegarde: {e}")
            self.session.open(
                MessageBox,
                f"❌ Erreur technique:\n\n{str(e)[:100]}",
                MessageBox.TYPE_ERROR
            )
    
    def delete_server(self):
        """Supprime un serveur via PortalManager"""
        if not self.manager or not self.servers or self.current_index >= len(self.servers):
            self.session.open(MessageBox, "❌ Aucun serveur à supprimer", MessageBox.TYPE_ERROR)
            return
        
        server = self.servers[self.current_index]
        server_name = server.get('name', 'Serveur inconnu')
        
        # Demander confirmation
        self.session.openWithCallback(
            lambda result: self.confirm_delete(result, self.current_index, server_name),
            MessageBox,
            f"⚠️ SUPPRIMER le serveur?\n\nNom: {server_name}\n\nCette action est irréversible!",
            MessageBox.TYPE_YESNO
        )
    
    def confirm_delete(self, result, index, server_name):
        """Confirme la suppression"""
        if not result:
            return
        
        try:
            # Supprimer via PortalManager
            delete_result = self.manager.delete_portal(index)
            
            if delete_result['success']:
                # Mettre à jour la liste locale
                self.servers = self.manager.get_portals()
                
                # Ajuster l'index
                if index < self.current_index:
                    self.current_index -= 1
                elif index == self.current_index:
                    self.current_index = max(0, len(self.servers) - 1)
                
                # Recharger ou effacer
                if self.servers and len(self.servers) > 0:
                    self.load_server_data(self.current_index)
                    message = f"✅ {delete_result.get('message', 'Serveur supprimé')}"
                else:
                    # Plus de serveurs, effacer les champs
                    self.config.server_name.value = "myserver"
                    self.config.server_host.value = "http://mysarver.com:8080"
                    self.config.server_mac.value = "00:1A:79:AA:1B:CD"
                    self.config.server_user.value = "user"
                    self.config.server_pass.value = "pass"
                    self["config"].setList(self.list)
                    self.update_server_info("Aucun serveur restant. Ajoutez-en un nouveau.")
                    message = f"✅ {delete_result.get('message', 'Serveur supprimé')}\n\nAucun serveur restant."
                
                self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=3)
            else:
                self.session.open(
                    MessageBox,
                    f"❌ Erreur:\n\n{delete_result.get('message', 'Erreur inconnue')}",
                    MessageBox.TYPE_ERROR
                )
                
        except Exception as e:
            print(f"[Configuration] Erreur suppression: {e}")
            self.session.open(
                MessageBox,
                "❌ Erreur technique lors de la suppression",
                MessageBox.TYPE_ERROR
            )
    
    def next_server(self):
        """Passe au serveur suivant"""
        if self.servers and len(self.servers) > 0:
            self.current_index = (self.current_index + 1) % len(self.servers)
            self.load_server_data(self.current_index)
            print(f"[Configuration] Navigation → serveur {self.current_index}")
    
    def close(self, result=None):
        """Ferme l'écran avec un résultat optionnel"""
        print("[Configuration] Fermeture de l'écran")
        super().close(result)