#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import os
import ssl
import urllib.request
import urllib.parse
import time


class StalkerTools:
    """Outils pour interagir avec l'API Stalker"""
    
    @staticmethod
    def test_connection(host, mac, timeout=10):
        """Teste la connexion au serveur Stalker"""
        try:
            portal = host.rstrip("/") + "/server/load.php"
            
            # Handshake
            url = portal + "?" + urllib.parse.urlencode({
                "type": "stb",
                "action": "handshake",
                "token": "",
                "JsHttpRequest": "1-xml"
            })
            
            headers = {
                "User-Agent": "Mozilla/5.0",
                "X-User-Agent": "Model: MAG254",
                "Referer": portal,
                "Cookie": f"mac={mac}; stb_lang=en; timezone=UTC"
            }
            
            req = urllib.request.Request(url, headers=headers)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=timeout)
            
            data = json.loads(response.read().decode())
            return data.get("js", {}).get("token") is not None
            
        except Exception as e:
            print(f"Erreur connexion: {e}")
            return False
    
    @staticmethod
    def get_all_channels(portal, mac, token, genre_id, max_pages=20):
        """Récupère toutes les chaînes d'un bouquet"""
        all_channels = []
        
        for page in range(1, max_pages + 1):
            try:
                url = portal + "?" + urllib.parse.urlencode({
                    "type": "itv",
                    "action": "get_ordered_list",
                    "genre": str(genre_id),
                    "p": str(page),
                    "JsHttpRequest": "1-xml"
                })
                
                headers = {
                    "User-Agent": "Mozilla/5.0",
                    "X-User-Agent": "Model: MAG254",
                    "Referer": portal,
                    "Cookie": f"mac={mac}; stb_lang=en",
                    "Authorization": f"Bearer {token}"
                }
                
                req = urllib.request.Request(url, headers=headers)
                context = ssl._create_unverified_context()
                response = urllib.request.urlopen(req, context=context, timeout=10)
                
                data = json.loads(response.read().decode())
                js = data.get("js", {})
                
                # Extraire les chaînes
                channels = []
                if isinstance(js, dict):
                    if "data" in js:
                        channels = js.get("data", [])
                    elif "channels" in js:
                        channels = js.get("channels", [])
                elif isinstance(js, list):
                    channels = js
                
                if not channels:
                    break
                
                all_channels.extend(channels)
                
                # Vérifier si dernière page
                if isinstance(js, dict) and js.get("max_page", 0) == page:
                    break
                    
                # Pause pour éviter de surcharger le serveur
                time.sleep(0.1)
                
            except Exception as e:
                print(f"Erreur page {page}: {e}")
                break
        
        return all_channels
    
    @staticmethod
    def analyze_response_structure(response_data):
        """Analyse la structure de la réponse API"""
        analysis = {
            "type": type(response_data).__name__,
            "keys": [],
            "sample_data": None
        }
        
        if isinstance(response_data, dict):
            analysis["keys"] = list(response_data.keys())
            # Prendre un échantillon
            if analysis["keys"]:
                first_key = analysis["keys"][0]
                if isinstance(response_data[first_key], (dict, list)):
                    analysis["sample_data"] = type(response_data[first_key]).__name__
                else:
                    analysis["sample_data"] = str(response_data[first_key])[:100]
        
        elif isinstance(response_data, list):
            analysis["keys"] = ["list_items"]
            if response_data:
                analysis["sample_data"] = type(response_data[0]).__name__
        
        return analysis
