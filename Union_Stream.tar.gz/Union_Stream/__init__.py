#!/usr/bin/python
# -*- coding: utf-8 -*-
from .main import Union_StreamMain
from Plugins.Plugin import PluginDescriptor
from .live import LiveScreen


def main(session, **kwargs):
    """Fonction principale pour lancer l'écran Live"""
    session.open(LiveScreen)


def Plugins(**kwargs):
    """Déclaration du plugin"""
    return PluginDescriptor(
        name="Union_Stream Live",
        description="Lecteur IPTV Stalker",
        where=PluginDescriptor.WHERE_EXTENSIONSMENU,
        fnc=main,
        icon="plugin.png"
    )
