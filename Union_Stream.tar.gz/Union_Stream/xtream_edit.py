#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Écran d'édition pour serveurs Xtream.
"""

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigList
from Components.config import ConfigSubsection, ConfigText, getConfigListEntry
from Components.Label import Label
from Components.Button import Button
from enigma import gRGB

class XtreamEditScreen(Screen):
    """
    Écran d'édition pour serveurs Xtream.
    """
    
    skin = """
    <screen position="center,center" size="1200,700" title="Xtream Edit">
        <ePixmap position="0,0" size="1200,700" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/skins/BG_Portal.png" zPosition="-1"/>
        
        <widget name="title" position="150,60" size="900,50" font="Bold;36" halign="center" valign="center" foregroundColor="#ffffff"/>
        
        <widget name="config" position="50,150" size="1100,400" itemHeight="45" backgroundColor="#19181c" transparent="0" foregroundColor="#ffffff" scrollbarMode="showOnDemand"/>
        
        <widget name="info_label" position="50,570" size="1100,80" font="Regular;22" halign="center" valign="center" foregroundColor="#00ff00" transparent="1"/>
        
        <widget name="key_green" position="100,650" size="200,50" font="Bold;24" halign="center" valign="center" backgroundColor="#006400" foregroundColor="#ffffff"/>
        <widget name="key_red" position="900,650" size="200,50" font="Bold;24" halign="center" valign="center" backgroundColor="#ff0000" foregroundColor="#ffffff"/>
    </screen>
    """
    
    def __init__(self, session, server_data=None, edit_index=None):
        Screen.__init__(self, session)
        
        self.edit_index = edit_index
        self.edit_mode = edit_index is not None
        self.server_data = server_data
        
        # Titre
        title = "✏️ Éditer Xtream" if self.edit_mode else "➕ Ajouter Xtream"
        self["title"] = Label(title)
        
        # Configuration
        self.config = ConfigSubsection()
        self.config.server_name = ConfigText(default="", fixed_size=False)
        self.config.server_url = ConfigText(default="http://", fixed_size=False)
        self.config.username = ConfigText(default="", fixed_size=False)
        self.config.password = ConfigText(default="", fixed_size=False)
        
        self.list = [
            getConfigListEntry("📛 Nom du serveur", self.config.server_name),
            getConfigListEntry("🌐 URL du serveur", self.config.server_url),
            getConfigListEntry("👤 Nom d'utilisateur", self.config.username),
            getConfigListEntry("🔑 Mot de passe", self.config.password)
        ]
        
        self["config"] = ConfigList(self.list)
        self["info_label"] = Label("Remplissez les champs et sauvegardez")
        
        # Boutons
        self["key_green"] = Button("💾 Sauvegarder" if self.edit_mode else "➕ Ajouter")
        self["key_red"] = Button("❌ Annuler")
        
        # Charger les données si mode édition
        if self.edit_mode and self.server_data:
            self.config.server_name.value = self.server_data.get('name', '')
            self.config.server_url.value = self.server_data.get('host', 'http://')
            self.config.username.value = self.server_data.get('username', '')
            self.config.password.value = self.server_data.get('password', '')
            self["config"].setList(self.list)
        
        # Actions
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions"], {
            "red": self.keyRed,
            "green": self.keyGreen,
            "ok": self.keyOk,
            "cancel": self.keyCancel,
            "up": self.keyUp,
            "down": self.keyDown,
            "left": self.keyLeft,
            "right": self.keyRight,
        }, -2)
        
        self.onLayoutFinish.append(self.initFocus)
    
    def initFocus(self):
        self.updateFocus()
    
    def updateFocus(self):
        try:
            self["config"].instance.setSelectionEnable(True)
        except:
            pass
    
    def keyOk(self):
        current = self["config"].getCurrent()
        if current and len(current) > 1:
            config_element = current[1]
            if hasattr(config_element, 'enabled') and config_element.enabled:
                from Screens.VirtualKeyBoard import VirtualKeyBoard
                
                field_titles = {
                    self.config.server_name: "Nom du serveur",
                    self.config.server_url: "URL du serveur",
                    self.config.username: "Nom d'utilisateur",
                    self.config.password: "Mot de passe"
                }
                
                title = field_titles.get(config_element, "Éditer")
                current_value = config_element.value
                
                self.session.openWithCallback(
                    lambda new_value: self.valueEntered(new_value, config_element),
                    VirtualKeyBoard,
                    title=title,
                    text=current_value
                )
    
    def valueEntered(self, new_value, config_element):
        if new_value is not None:
            config_element.value = new_value
            self["config"].setList(self.list)
            self["info_label"].setText("✓ Valeur mise à jour")
    
    def keyUp(self):
        if self["config"]:
            self["config"].instance.moveSelection(self["config"].instance.moveUp)
    
    def keyDown(self):
        if self["config"]:
            self["config"].instance.moveSelection(self["config"].instance.moveDown)
    
    def keyLeft(self):
        if self["config"]:
            self["config"].instance.moveSelection(self["config"].instance.moveLeft)
    
    def keyRight(self):
        if self["config"]:
            self["config"].instance.moveSelection(self["config"].instance.moveRight)
    
    def keyGreen(self):
        self.save_server()
    
    def keyRed(self):
        self.close()
    
    def keyCancel(self):
        self.close()
    
    def save_server(self):
        name = self.config.server_name.value.strip()
        url = self.config.server_url.value.strip()
        username = self.config.username.value.strip()
        password = self.config.password.value.strip()
        
        # Validation
        errors = []
        if not name:
            errors.append("Nom requis")
        if not url:
            errors.append("URL requise")
        if not username:
            errors.append("Nom d'utilisateur requis")
        if not password:
            errors.append("Mot de passe requis")
        
        if errors:
            self["info_label"].setText("❌ " + ", ".join(errors))
            return
        
        # Importer le gestionnaire
        from .server_manager import ServerManager
        manager = ServerManager()
        
        if self.edit_mode:
            # Mise à jour
            result = manager.update_server(
                self.edit_index,
                name=name,
                host=url,
                username=username,
                password=password,
                test_connection=True
            )
        else:
            # Ajout
            result = manager.add_server(
                "xtream",
                name=name,
                host=url,
                username=username,
                password=password,
                test_connection=True
            )
        
        if result['success']:
            self["info_label"].setText("✅ Serveur sauvegardé")
            # Fermer après un délai
            from enigma import eTimer
            self.timer = eTimer()
            self.timer.callback.append(self.close_success)
            self.timer.start(2000, True)
        else:
            self["info_label"].setText(f"❌ {result['message']}")
    
    def close_success(self):
        self.close(True)