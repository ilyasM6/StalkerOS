#!/usr/bin/python
# -*- coding: utf-8 -*-

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Button import Button
from Components.Pixmap import Pixmap
from Screens.MessageBox import MessageBox
from enigma import eServiceReference, eTimer

import json
import os
import ssl
import urllib.request
import urllib.parse
import sys
import traceback
import base64


class LiveScreen(Screen):

    skin = """
    <screen name="LiveScreen" position="center,center" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent">
        <!-- Fond pour les bouquets -->
        <widget name="bg_bouquets" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/skins/BG_Portal.png" 
                position="center,center" size="1920,1080" zPosition="0" alphatest="blend" />
        <!-- Fond pour les chaînes -->
        <widget name="bg_channels" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/skins/BG_Portal.png" 
                position="center,center" size="1920,1080" zPosition="0" alphatest="blend" />

        <widget name="title" position="0,20" size="1920,60" font="Bold;45" halign="center" backgroundColor="transparent" transparent="1"/>
        <widget name="server_info" position="0,90" size="1920,35" font="Regular;26" halign="center" backgroundColor="transparent" transparent="1"/>

        <!-- Liste des bouquets (gauche) -->
        <widget name="bouquet_list" position="50,150" size="850,750" itemHeight="45" font="Regular;28" zPosition="1" backgroundColor="transparent" transparent="1" foregroundColor="white"/>
        
        <!-- Liste des chaînes (droite) -->
        <widget name="channel_list" position="1000,150" size="850,750" itemHeight="45" font="Regular;28" zPosition="1" backgroundColor="transparent" transparent="1" foregroundColor="white"/>

        <!-- Status principal -->
        <widget name="status" position="50,920" size="850,35" font="Regular;26" halign="left" valign="center" backgroundColor="transparent" transparent="1"/>
        
        <!-- Informations de pagination (à droite) -->
        <widget name="page_info" position="1000,920" size="850,35" font="Regular;26" halign="right" valign="center" backgroundColor="transparent" transparent="1"/>
        
        <!-- Info sélection -->
        <widget name="info" position="0,960" size="1920,40" font="Regular;26" halign="center" valign="center" backgroundColor="transparent" transparent="1"/>

        <!-- Boutons de navigation -->
        <widget name="key_red" position="50,1010" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#e74c3c" transparent="0" foregroundColor="white"/>
        <widget name="key_green" position="300,1010" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#2ecc71" transparent="0" foregroundColor="white"/>
        <widget name="key_yellow" position="550,1010" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#f1c40f" transparent="0" foregroundColor="black"/>
        <widget name="key_blue" position="800,1010" size="200,50" font="Regular;26" halign="center" valign="center" backgroundColor="#3498db" transparent="0" foregroundColor="white"/>
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        # Fond pour les deux listes
        self["bg_bouquets"] = Pixmap()
        self["bg_channels"] = Pixmap()

        # Widgets principaux
        self["title"] = Label("📡 Live TV")
        self["server_info"] = Label("")
        self["status"] = Label("Initialisation...")
        self["info"] = Label("TéléStalker Live TV")
        self["page_info"] = Label("")

        # Listes
        self["bouquet_list"] = MenuList([])
        self["channel_list"] = MenuList([])

        # Boutons avec labels explicites
        self["key_red"] = Button("🔴 Quitter")
        self["key_green"] = Button("✅ Lire")
        self["key_yellow"] = Button("🔄 Recharger")
        self["key_blue"] = Button("📋 Toutes")

        # Actions de télécommande améliorées
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions", "NumberActions", "MenuActions"],
            {
                # Navigation directionnelle
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                
                # Actions principales
                "ok": self.keyOk,
                "cancel": self.exit,
                "red": self.exit,
                
                # Boutons couleurs avec pagination
                "green": self.keyGreen,     # Lire
                "yellow": self.keyYellow,   # Recharger toutes les chaînes
                "blue": self.keyBlue,       # Voir toutes les chaînes
                
                # Pagination avancée
                "pageUp": self.prevPage,
                "pageDown": self.nextPage,
                "nextBouquet": self.nextBouquet,
                "prevBouquet": self.prevBouquet,
                
                # Menu pour options
                "menu": self.show_options_menu,
                
                # Navigation par numéros (0-9)
                "0": lambda: self.numberKey(0),
                "1": lambda: self.numberKey(1),
                "2": lambda: self.numberKey(2),
                "3": lambda: self.numberKey(3),
                "4": lambda: self.numberKey(4),
                "5": lambda: self.numberKey(5),
                "6": lambda: self.numberKey(6),
                "7": lambda: self.numberKey(7),
                "8": lambda: self.numberKey(8),
                "9": lambda: self.numberKey(9),
            }, -2
        )

        # Variables d'état
        self.server_type = None  # 'stalker' ou 'xtream'
        self.server_config = None  # Configuration complète du serveur
        self.portal = None
        self.mac = None
        self.token = None
        self.username = None
        self.password = None
        self.base_url = None  # Pour Xtream

        self.bouquets = []
        self.channels = []
        self.all_channels = []  # Stocke TOUTES les chaînes
        self.total_channels = 0
        self.max_page = 1
        self.per_page = 50  # Valeur par défaut

        self.bouquet_index = 0
        self.channel_index = 0
        self.focus = "bouquet"  # 'bouquet' ou 'channel'

        self.playing = False
        self.overlay_visible = False
        self.current_genre_id = None
        self.current_page = 1
        self.show_all_mode = False  # Mode pour afficher toutes les chaînes

        # Timer pour cacher l'overlay
        self.hide_timer = eTimer()
        self.hide_timer.callback.append(self.hide_overlay)

        # Timer pour les erreurs différées
        self.error_timer = None

        # Fichier de debug
        self.debug_file = "/tmp/Union_Stream_debug.log"
        
        # Démarrer le chargement après le rendu
        self.onLayoutFinish.append(self.start)

    def debug_log(self, message):
        """Écrit un message dans le fichier de debug"""
        try:
            with open(self.debug_file, "a") as f:
                f.write(f"{message}\n")
        except:
            pass

    def start(self):
        """Démarre le chargement après l'initialisation de l'interface"""
        self.load_active_server()

    def load_active_server(self):
        """Charge le serveur actif depuis la configuration"""
        # Vérifier d'abord le nouveau fichier unifié
        unified_config = "/etc/enigma2/Union_Stream/servers.json"
        old_config = "/etc/enigma2/Union_Stream/portals.json"
        
        config_file = None
        if os.path.exists(unified_config):
            config_file = unified_config
            self["status"].setText("📡 Chargement depuis servers.json...")
        elif os.path.exists(old_config):
            config_file = old_config
            self["status"].setText("📡 Chargement depuis portals.json...")
        
        if not config_file:
            # Afficher l'erreur dans le label au lieu d'ouvrir une MessageBox
            self["status"].setText("❌ Aucun serveur configuré")
            self["info"].setText("Configurez un serveur dans 'Servers'")
            self["server_info"].setText("⚠️ Configuration manquante")
            
            # Nettoyer les listes
            self["bouquet_list"].setList(["Configuration requise"])
            self["channel_list"].setList(["Ajoutez un serveur d'abord"])
            
            # Programmer un message d'erreur différé
            self.schedule_error_message("❌ Aucun serveur configuré\n\nVeuillez configurer un serveur dans le menu 'Servers'.")
            return

        try:
            with open(config_file, "r") as f:
                data = json.load(f)

            # Rechercher le serveur actif - compatibilité avec les deux formats
            active_server = None
            
            if "servers" in data:  # Nouveau format unifié
                for server in data.get("servers", []):
                    if server.get("active"):
                        active_server = server
                        break
            elif "portals" in data:  # Ancien format
                for portal in data.get("portals", []):
                    if portal.get("active"):
                        active_server = portal
                        break
            
            if not active_server:
                self["status"].setText("⚠️ Aucun serveur actif")
                self["info"].setText("Activez un serveur dans 'Servers'")
                self["server_info"].setText("🔍 Serveur inactif")
                
                self["bouquet_list"].setList(["Aucun serveur actif"])
                self["channel_list"].setList(["Activez un serveur d'abord"])
                return

            # Sauvegarder la configuration complète
            self.server_config = active_server
            self.server_type = active_server.get('type', 'stalker')
            
            # Configurer selon le type de serveur
            server_name = active_server.get('name', 'Serveur inconnu')
            
            if self.server_type == 'stalker':
                self.portal = active_server["host"].rstrip("/") + "/server/load.php"
                self.mac = active_server["mac"]
                self["server_info"].setText(f"🌐 {server_name} (Stalker)")
                self["status"].setText("Connexion au serveur Stalker...")
                # Obtenir le token d'authentification
                self.load_token()
                
            elif self.server_type == 'xtream':
                self.base_url = active_server["host"].rstrip("/")
                self.username = active_server.get("username", "")
                self.password = active_server.get("password", "")
                self["server_info"].setText(f"🌐 {server_name} (Xtream)")
                self["status"].setText("Connexion au serveur Xtream...")
                # Charger directement les catégories Xtream
                self.load_xtream_categories()
                
            else:
                self["status"].setText("❌ Type de serveur inconnu")
                self["info"].setText("Type non supporté")
                self.schedule_error_message(f"❌ Type de serveur inconnu: {self.server_type}")
                return

        except json.JSONDecodeError:
            self["status"].setText("❌ Fichier corrompu")
            self["info"].setText("Recréez la configuration")
            self.schedule_error_message("❌ Fichier de configuration corrompu\n\nSupprimez et recréez la configuration.")
        except Exception as e:
            self["status"].setText(f"❌ Erreur: {str(e)[:30]}")
            self.schedule_error_message(f"❌ Erreur chargement serveur:\n{str(e)}")

    def schedule_error_message(self, msg):
        """Programme un message d'erreur pour plus tard"""
        def show_error_delayed():
            try:
                self.session.open(MessageBox, msg, MessageBox.TYPE_ERROR)
            except:
                # Fallback: afficher dans le status
                self["status"].setText(f"❌ {msg[:50]}")
        
        # Utiliser un timer pour ouvrir la MessageBox après l'initialisation
        if not hasattr(self, 'error_timer') or self.error_timer is None:
            self.error_timer = eTimer()
        
        self.error_timer.callback.append(show_error_delayed)
        self.error_timer.start(2000, True)  # 2 secondes de délai

    def load_token(self):
        """Récupère le token d'authentification du serveur Stalker"""
        try:
            # URL pour le handshake
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "stb",
                "action": "handshake",
                "token": "",
                "JsHttpRequest": "1-xml"
            })

            # Headers pour simuler un MAG device
            headers = {
                "User-Agent": "Mozilla/5.0",
                "X-User-Agent": "Model: MAG254; Revision: 2.13.0-r26-pub-250; Serial: 00:1A:79:00:00:00",
                "Referer": self.portal,
                "Cookie": f"mac={self.mac}; stb_lang=en; timezone=UTC"
            }

            # Requête HTTP
            req = urllib.request.Request(url, headers=headers)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=10)
            
            # Parser la réponse
            data = json.loads(response.read().decode())
            
            if "js" in data and "token" in data["js"]:
                self.token = data["js"]["token"]
                self["status"].setText("✅ Connecté au serveur")
                
                # Charger les bouquets
                self.load_bouquets()
            else:
                self["status"].setText("❌ Token non reçu")
                self.schedule_error_message("❌ Token non reçu du serveur")

        except urllib.error.URLError as e:
            self["status"].setText("❌ Erreur réseau")
            self.schedule_error_message(f"❌ Erreur réseau:\n{str(e)}")
        except Exception as e:
            self["status"].setText("❌ Erreur auth")
            self.schedule_error_message(f"❌ Erreur authentification:\n{str(e)}")

    def load_bouquets(self):
        """Charge la liste des bouquets (genres) pour Stalker"""
        try:
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "itv",
                "action": "get_genres",
                "JsHttpRequest": "1-xml"
            })

            req = urllib.request.Request(url, headers=self.get_headers())
            response = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=10)
            
            data = json.loads(response.read().decode())
            self.bouquets = data.get("js", [])
            
            if not self.bouquets:
                self["bouquet_list"].setList(["Aucun bouquet disponible"])
                self["status"].setText("❌ Aucun bouquet trouvé")
                return
            
            # Afficher les bouquets
            bouquet_items = []
            for bouquet in self.bouquets:
                title = bouquet.get('title', 'Bouquet sans nom')
                bouquet_items.append(f"📁 {title}")
            
            self["bouquet_list"].setList(bouquet_items)
            self["status"].setText(f"✅ {len(self.bouquets)} bouquets chargés")
            self["info"].setText(f"Sélectionnez un bouquet ({len(self.bouquets)} disponibles)")
            
            # Sélectionner le premier bouquet
            if self.bouquets:
                self.bouquet_index = 0
                self["bouquet_list"].moveToIndex(0)
                self["info"].setText(f"Bouquet sélectionné: {self.bouquets[0].get('title', '')}")

        except Exception as e:
            self["status"].setText("❌ Erreur bouquets")
            self.schedule_error_message(f"❌ Erreur chargement bouquets:\n{str(e)}")

    def load_xtream_categories(self):
        """Charge les catégories Live TV depuis Xtream"""
        try:
            # Construire l'URL pour les catégories Live
            url = f"{self.base_url}/player_api.php?username={self.username}&password={self.password}&action=get_live_categories"
            
            self.debug_log(f"Chargement catégories Xtream: {url}")
            
            req = urllib.request.Request(url)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=10)
            
            data = json.loads(response.read().decode())
            
            if not data:
                self["bouquet_list"].setList(["Aucune catégorie disponible"])
                self["status"].setText("❌ Aucune catégorie trouvée")
                return
            
            # Formater les catégories
            self.bouquets = []
            bouquet_items = []
            
            for idx, category in enumerate(data):
                if isinstance(category, dict):
                    category_id = category.get('category_id', idx)
                    category_name = category.get('category_name', f'Catégorie {idx}')
                    
                    # Ajouter aux bouquets
                    self.bouquets.append({
                        'id': category_id,
                        'title': category_name,
                        'category_id': category_id
                    })
                    
                    bouquet_items.append(f"📁 {category_name}")
                else:
                    # Format simple
                    self.bouquets.append({
                        'id': idx,
                        'title': category,
                        'category_id': idx
                    })
                    bouquet_items.append(f"📁 {category}")
            
            self["bouquet_list"].setList(bouquet_items)
            self["status"].setText(f"✅ {len(self.bouquets)} catégories chargées")
            self["info"].setText(f"Sélectionnez une catégorie ({len(self.bouquets)} disponibles)")
            
            # Sélectionner la première catégorie
            if self.bouquets:
                self.bouquet_index = 0
                self["bouquet_list"].moveToIndex(0)
                self["info"].setText(f"Catégorie sélectionnée: {self.bouquets[0].get('title', '')}")
            
        except Exception as e:
            self.debug_log(f"ERREUR load_xtream_categories: {traceback.format_exc()}")
            self["status"].setText("❌ Erreur catégories Xtream")
            self.schedule_error_message(f"❌ Erreur chargement catégories Xtream:\n{str(e)}")

    def load_channels(self, genre_id=None, page=1):
        """Charge les chaînes d'un bouquet avec pagination"""
        self.show_all_mode = False  # Désactiver le mode "toutes"
        
        # Déterminer le genre_id selon le type de serveur
        if self.server_type == 'stalker':
            if genre_id is None and self.current_genre_id:
                genre_id = self.current_genre_id
            elif genre_id is None and self.bouquets:
                if self.bouquet_index < len(self.bouquets):
                    genre_id = self.bouquets[self.bouquet_index].get("id")
            
            if not genre_id:
                self["status"].setText("❌ ID de bouquet invalide")
                return
            
            self.current_genre_id = genre_id
            self.current_page = page
            
            # Charger les chaînes Stalker
            self.load_stalker_channels(genre_id, page)
            
        elif self.server_type == 'xtream':
            if self.bouquets and self.bouquet_index < len(self.bouquets):
                category = self.bouquets[self.bouquet_index]
                category_id = category.get('category_id')
                
                if not category_id:
                    self["status"].setText("❌ ID de catégorie invalide")
                    return
                
                self.current_genre_id = category_id
                self.current_page = page
                
                # Charger les chaînes Xtream
                self.load_xtream_channels(category_id, page)

    def load_stalker_channels(self, genre_id, page=1):
        """Charge les chaînes depuis un serveur Stalker"""
        try:
            # Log pour debug
            self.debug_log(f"=== CHARGEMENT CHAINES STALKER ===")
            self.debug_log(f"Genre ID: {genre_id}")
            self.debug_log(f"Page: {page}")
            
            url = self.portal + "?" + urllib.parse.urlencode({
                "type": "itv",
                "action": "get_ordered_list",
                "genre": str(genre_id),
                "p": str(page),
                "JsHttpRequest": "1-xml"
            })

            self.debug_log(f"URL: {url}")
            self["status"].setText(f"Chargement page {page}...")
            
            req = urllib.request.Request(url, headers=self.get_headers())
            response = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=15)
            
            data = json.loads(response.read().decode())
            js = data.get("js", {})
            
            # Log de la réponse complète
            self.debug_log(f"Réponse complète: {json.dumps(js, indent=2)[:500]}...")
            
            # Vérifier différentes structures de réponse
            channels_data = []
            
            if isinstance(js, dict):
                if "data" in js:
                    channels_data = js.get("data", [])
                elif "channels" in js:
                    channels_data = js.get("channels", [])
                elif len(js) > 0 and isinstance(list(js.values())[0], dict):
                    # Peut-être un dict où les valeurs sont les chaînes
                    channels_data = list(js.values())
            elif isinstance(js, list):
                channels_data = js
            
            self.channels = channels_data
            self.debug_log(f"Nombre de chaînes trouvées: {len(self.channels)}")
            
            # Extraire les données de pagination
            if isinstance(js, dict):
                self.total_channels = js.get("total_items", len(self.channels))
                self.max_page = js.get("max_page", 1)
            else:
                self.total_channels = len(self.channels)
                self.max_page = 1
            
            # Si on a moins de 20 chaînes et max_page=1, essayer de charger plus
            if len(self.channels) < 20 and self.max_page == 1 and page == 1:
                self.debug_log("Peu de chaînes, tentative de chargement étendu...")
                self.load_all_stalker_channels(genre_id)
                return
            
            # Afficher les chaînes
            self.display_channels()
            
        except Exception as e:
            error_msg = str(e)
            self.debug_log(f"ERREUR load_stalker_channels: {traceback.format_exc()}")
            
            if "timeout" in error_msg.lower():
                self["status"].setText("❌ Timeout - Réessayez")
            else:
                self["status"].setText(f"❌ Erreur: {error_msg[:30]}")
            self["page_info"].setText("")

    def load_xtream_channels(self, category_id, page=1):
        """Charge les chaînes depuis un serveur Xtream"""
        try:
            # Calculer l'offset pour la pagination
            # Xtream ne supporte pas nativement la pagination, on simule
            items_per_page = self.per_page
            start_index = (page - 1) * items_per_page
            
            # URL pour les chaînes d'une catégorie
            url = f"{self.base_url}/player_api.php?username={self.username}&password={self.password}&action=get_live_streams&category_id={category_id}"
            
            self.debug_log(f"Chargement chaînes Xtream: {url}")
            self["status"].setText(f"Chargement catégorie...")
            
            req = urllib.request.Request(url)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=15)
            
            data = json.loads(response.read().decode())
            
            if not data:
                self.channels = []
                self.total_channels = 0
                self.max_page = 1
                self["channel_list"].setList(["Aucune chaîne dans cette catégorie"])
                self["status"].setText("❌ Aucune chaîne trouvée")
                return
            
            # Toutes les chaînes
            all_channels = data
            
            # Calculer la pagination
            self.total_channels = len(all_channels)
            self.max_page = max(1, (self.total_channels + items_per_page - 1) // items_per_page)
            
            # Extraire les chaînes pour la page courante
            end_index = min(start_index + items_per_page, self.total_channels)
            self.channels = all_channels[start_index:end_index]
            
            self.debug_log(f"Chaînes Xtream: {self.total_channels} total, page {page}/{self.max_page}")
            
            # Afficher les chaînes
            self.display_channels()
            
        except Exception as e:
            error_msg = str(e)
            self.debug_log(f"ERREUR load_xtream_channels: {traceback.format_exc()}")
            
            if "timeout" in error_msg.lower():
                self["status"].setText("❌ Timeout - Réessayez")
            else:
                self["status"].setText(f"❌ Erreur: {error_msg[:30]}")
            self["page_info"].setText("")

    def load_all_stalker_channels(self, genre_id):
        """Charge TOUTES les chaînes d'un bouquet Stalker en parcourant toutes les pages"""
        try:
            self.debug_log("=== CHARGEMENT DE TOUTES LES CHAINES STALKER ===")
            
            all_channels = []
            page = 1
            max_attempts = 10  # Maximum 10 pages pour éviter la boucle infinie
            
            while page <= max_attempts:
                self.debug_log(f"Chargement page {page}...")
                
                url = self.portal + "?" + urllib.parse.urlencode({
                    "type": "itv",
                    "action": "get_ordered_list",
                    "genre": str(genre_id),
                    "p": str(page),
                    "JsHttpRequest": "1-xml"
                })
                
                req = urllib.request.Request(url, headers=self.get_headers())
                response = urllib.request.urlopen(req, context=ssl._create_unverified_context(), timeout=10)
                data = json.loads(response.read().decode())
                js = data.get("js", {})
                
                # Extraire les chaînes
                page_channels = []
                if isinstance(js, dict):
                    if "data" in js:
                        page_channels = js.get("data", [])
                    elif "channels" in js:
                        page_channels = js.get("channels", [])
                elif isinstance(js, list):
                    page_channels = js
                
                if not page_channels:
                    self.debug_log(f"Aucune chaîne à la page {page}, arrêt.")
                    break
                
                all_channels.extend(page_channels)
                self.debug_log(f"{len(page_channels)} chaînes ajoutées, total: {len(all_channels)}")
                
                # Vérifier si c'était la dernière page
                if isinstance(js, dict):
                    max_page = js.get("max_page", 0)
                    if max_page > 0 and page >= max_page:
                        self.debug_log(f"Dernière page atteinte: {page}/{max_page}")
                        break
                
                # Si on a moins de 10 chaînes, probablement fini
                if len(page_channels) < 10:
                    self.debug_log("Moins de 10 chaînes, probablement fini")
                    break
                
                page += 1
            
            # Mettre à jour les données
            self.channels = all_channels
            self.all_channels = all_channels.copy()  # Sauvegarder pour le mode "toutes"
            self.total_channels = len(all_channels)
            self.max_page = 1  # En mode toutes, on a qu'une page
            
            # Afficher
            self.display_channels()
            
        except Exception as e:
            self.debug_log(f"ERREUR load_all_stalker_channels: {traceback.format_exc()}")
            self["status"].setText(f"❌ Erreur chargement: {str(e)[:30]}")

    def load_all_xtream_channels(self, category_id):
        """Charge TOUTES les chaînes d'une catégorie Xtream"""
        try:
            # URL pour toutes les chaînes de la catégorie
            url = f"{self.base_url}/player_api.php?username={self.username}&password={self.password}&action=get_live_streams&category_id={category_id}"
            
            self.debug_log("Chargement toutes les chaînes Xtream")
            self["status"].setText("Chargement toutes les chaînes...")
            
            req = urllib.request.Request(url)
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, context=context, timeout=15)
            
            data = json.loads(response.read().decode())
            
            if not data:
                self.channels = []
                self.all_channels = []
                self["channel_list"].setList(["Aucune chaîne"])
                self["status"].setText("❌ Aucune chaîne trouvée")
                return
            
            # Mettre à jour les données
            self.channels = data
            self.all_channels = data.copy()
            self.total_channels = len(data)
            self.max_page = 1
            
            # Afficher
            self.display_channels()
            
        except Exception as e:
            self.debug_log(f"ERREUR load_all_xtream_channels: {traceback.format_exc()}")
            self["status"].setText(f"❌ Erreur chargement: {str(e)[:30]}")

    def display_channels(self):
        """Affiche les chaînes dans la liste (commun à Stalker et Xtream)"""
        # Calculer les statistiques
        if self.max_page > 1:
            start_item = (self.current_page - 1) * self.per_page + 1
            end_item = min(self.current_page * self.per_page, self.total_channels)
        else:
            start_item = 1
            end_item = len(self.channels)
        
        # Mettre à jour l'affichage des chaînes
        channel_items = []
        for idx, channel in enumerate(self.channels):
            # Formater selon le type de serveur
            if self.server_type == 'stalker':
                number = channel.get('number', '')
                name = channel.get('name', 'Chaîne inconnue')
                if number:
                    channel_items.append(f"{number}. {name}")
                else:
                    channel_items.append(f"{idx+1}. {name}")
            elif self.server_type == 'xtream':
                name = channel.get('name', 'Chaîne inconnue')
                num = channel.get('num', idx + 1)
                channel_items.append(f"{num}. {name}")
        
        self["channel_list"].setList(channel_items)
        
        # Mettre à jour les informations de pagination
        if self.max_page > 1:
            page_info = f"📄 Page {self.current_page}/{self.max_page} | "
            page_info += f"Chaînes {start_item}-{end_item} sur {self.total_channels}"
            self["page_info"].setText(page_info)
            self["key_yellow"].setText("◀️ Page -")
            self["key_blue"].setText("▶️ Page +")
        else:
            page_info = f"📺 {len(self.channels)} chaînes"
            self["page_info"].setText(page_info)
            self["key_yellow"].setText("🔄 Recharger")
            self["key_blue"].setText("📋 Toutes")
        
        # Mettre à jour le status
        bouquet_name = ""
        if self.bouquets and self.bouquet_index < len(self.bouquets):
            bouquet_name = self.bouquets[self.bouquet_index].get('title', '')
        
        self["status"].setText(f"✅ {len(self.channels)} chaînes chargées")
        
        if self.channels:
            self.channel_index = 0
            self["channel_list"].moveToIndex(0)
            self.update_selection_info()
        else:
            self["info"].setText("❌ Aucune chaîne dans ce bouquet")

    def show_all_channels(self):
        """Affiche toutes les chaînes en une seule liste"""
        if not self.all_channels:
            self["status"].setText("❌ Aucune chaîne à afficher")
            return
        
        self.show_all_mode = True
        self.channels = self.all_channels.copy()
        
        # Afficher
        channel_items = []
        for idx, channel in enumerate(self.channels):
            # Formater selon le type de serveur
            if self.server_type == 'stalker':
                number = channel.get('number', '')
                name = channel.get('name', 'Chaîne inconnue')
                if number:
                    channel_items.append(f"{number}. {name}")
                else:
                    channel_items.append(f"{idx+1}. {name}")
            elif self.server_type == 'xtream':
                name = channel.get('name', 'Chaîne inconnue')
                num = channel.get('num', idx + 1)
                channel_items.append(f"{num}. {name}")
        
        self["channel_list"].setList(channel_items)
        self["page_info"].setText(f"📺 {len(self.channels)} chaînes (liste complète)")
        self["status"].setText(f"✅ {len(self.channels)} chaînes affichées")
        
        if self.channels:
            self.channel_index = 0
            self["channel_list"].moveToIndex(0)
            self.update_selection_info()

    def update_selection_info(self):
        """Met à jour les informations de sélection"""
        if self.focus == "bouquet" and self.bouquets:
            bouquet = self.bouquets[self.bouquet_index]
            name = bouquet.get('title', 'Bouquet sans nom')
            server_type_text = "Stalker" if self.server_type == 'stalker' else "Xtream"
            self["info"].setText(f"📁 {name} ({server_type_text})")
        
        elif self.focus == "channel" and self.channels:
            if self.channel_index < len(self.channels):
                channel = self.channels[self.channel_index]
                
                # Formater selon le type de serveur
                if self.server_type == 'stalker':
                    number = channel.get('number', '')
                    name = channel.get('name', 'Chaîne inconnue')
                    
                    # Calculer la position
                    if self.show_all_mode:
                        position = f"{self.channel_index + 1}/{len(self.channels)}"
                    elif self.max_page > 1:
                        absolute_position = ((self.current_page - 1) * self.per_page) + self.channel_index + 1
                        position = f"#{absolute_position}/{self.total_channels}"
                    else:
                        position = f"{self.channel_index + 1}/{len(self.channels)}"
                    
                    info_text = f"📺 "
                    if number:
                        info_text += f"{number}. "
                    info_text += f"{name} ({position})"
                    
                    # Ajouter l'info EPG si disponible
                    epg = channel.get('epg', [])
                    if epg and isinstance(epg, list) and len(epg) > 0:
                        current_program = epg[0]
                        if isinstance(current_program, dict):
                            program_name = current_program.get('name', '')
                            if program_name:
                                info_text += f" | 📻 {program_name}"
                    
                    self["info"].setText(info_text)
                    
                elif self.server_type == 'xtream':
                    name = channel.get('name', 'Chaîne inconnue')
                    num = channel.get('num', self.channel_index + 1)
                    
                    # Calculer la position
                    if self.show_all_mode:
                        position = f"{self.channel_index + 1}/{len(self.channels)}"
                    elif self.max_page > 1:
                        absolute_position = ((self.current_page - 1) * self.per_page) + self.channel_index + 1
                        position = f"#{absolute_position}/{self.total_channels}"
                    else:
                        position = f"{self.channel_index + 1}/{len(self.channels)}"
                    
                    info_text = f"📺 {num}. {name} ({position})"
                    
                    # Ajouter l'extension si disponible
                    ext = channel.get('container_extension', '')
                    if ext:
                        info_text += f" [{ext}]"
                    
                    self["info"].setText(info_text)

    def get_headers(self):
        """Retourne les headers HTTP pour les requêtes Stalker"""
        headers = {
            "User-Agent": "Mozilla/5.0",
            "X-User-Agent": "Model: MAG254",
            "Referer": self.portal,
            "Cookie": f"mac={self.mac}; stb_lang=en"
        }
        
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        
        return headers

    # ==================== GESTION DE LA LECTURE ====================

    def play_channel(self):
        """Joue la chaîne sélectionnée"""
        if not self.channels or self.channel_index >= len(self.channels):
            self["status"].setText("❌ Aucune chaîne sélectionnée")
            return

        channel = self.channels[self.channel_index]
        name = channel.get("name", "IPTV")
        
        # Obtenir l'URL de flux selon le type de serveur
        if self.server_type == 'stalker':
            cmd = channel.get("cmd")
            if not cmd:
                self["status"].setText(f"❌ Flux invalide pour: {name}")
                return

            # Nettoyer l'URL si elle contient "ffmpeg"
            if cmd.startswith("ffmpeg "):
                cmd = cmd.replace("ffmpeg ", "").strip()
            
            # Vérifier si c'est une URL valide
            if not (cmd.startswith("http://") or cmd.startswith("https://") or cmd.startswith("rtsp://") or cmd.startswith("rtmp://")):
                self["status"].setText("❌ Format de flux non supporté")
                return
            
            stream_url = cmd
            
        elif self.server_type == 'xtream':
            # Construire l'URL de flux Xtream
            stream_id = channel.get('stream_id')
            if not stream_id:
                self["status"].setText(f"❌ ID de flux invalide pour: {name}")
                return
            
            # Format: http://server:port/live/username/password/stream_id.ext
            extension = channel.get('container_extension', 'ts')
            
            # Extraire les parties de l'URL de base
            from urllib.parse import urlparse
            parsed = urlparse(self.base_url)
            
            if parsed.scheme and parsed.netloc:
                # URL complète fournie
                base_url = f"{parsed.scheme}://{parsed.netloc}"
            else:
                # Juste l'adresse IP/port
                base_url = f"http://{self.base_url}"
            
            stream_url = f"{base_url}/live/{self.username}/{self.password}/{stream_id}.{extension}"
        
        else:
            self["status"].setText("❌ Type de serveur non supporté")
            return

        try:
            # Créer la référence de service Enigma2
            sref = eServiceReference(4097, 0, stream_url)
            sref.setName(name)
            
            # Marquer comme stream
            sref.setData(0, 1)
            
            # Démarrer la lecture
            self.session.nav.playService(sref)
            self.playing = True
            
            # Afficher le message de confirmation
            self["status"].setText(f"▶️ Lecture: {name}")
            self["info"].setText(f"🔊 {name} en cours de lecture...")
            
            # Cacher l'overlay après 5 secondes
            self.hide_timer.start(5000, True)
            
        except Exception as e:
            self["status"].setText(f"❌ Erreur lecture: {str(e)[:30]}")

    def show_overlay(self):
        """Affiche l'overlay de contrôle"""
        if not self.playing:
            return
        
        self.show()
        self.overlay_visible = True
        
        # Redémarrer le timer de disparition
        self.hide_timer.stop()
        self.hide_timer.start(5000, True)

    def hide_overlay(self):
        """Cache l'overlay"""
        if self.playing and self.overlay_visible:
            self.hide()
            self.overlay_visible = False

    # ==================== NAVIGATION CLAVIER ====================

    def keyOk(self):
        """Action principale sur OK"""
        if self.playing:
            # Si en cours de lecture, toggle overlay
            if self.overlay_visible:
                # Dans overlay, OK = action selon le focus
                if self.focus == "bouquet":
                    # Changer de bouquet
                    if self.server_type == 'stalker':
                        self.load_channels(self.bouquets[self.bouquet_index]["id"], 1)
                    elif self.server_type == 'xtream':
                        category_id = self.bouquets[self.bouquet_index].get('category_id')
                        self.load_channels(category_id, 1)
                    self.focus = "channel"
                else:
                    # Changer de chaîne
                    self.play_channel()
            else:
                # Afficher l'overlay
                self.show_overlay()
        else:
            # Si pas en lecture, OK = action normale
            if self.focus == "bouquet":
                # Charger les chaînes du bouquet sélectionné
                if self.bouquets:
                    if self.server_type == 'stalker':
                        self.load_channels(self.bouquets[self.bouquet_index]["id"], 1)
                    elif self.server_type == 'xtream':
                        category_id = self.bouquets[self.bouquet_index].get('category_id')
                        self.load_channels(category_id, 1)
                    self.focus = "channel"
            else:
                # Lire la chaîne sélectionnée
                self.play_channel()

    def keyGreen(self):
        """Bouton vert = Lire la chaîne"""
        if self.focus == "channel" and self.channels:
            self.play_channel()
        else:
            self["info"].setText("Sélectionnez d'abord une chaîne")

    def keyYellow(self):
        """Bouton jaune = Action selon le mode"""
        if self.max_page > 1 and not self.show_all_mode:
            # Mode pagination: page précédente
            self.prevPage()
        else:
            # Mode normal: recharger toutes les chaînes
            if self.current_genre_id:
                if self.server_type == 'stalker':
                    self.load_all_stalker_channels(self.current_genre_id)
                elif self.server_type == 'xtream':
                    self.load_all_xtream_channels(self.current_genre_id)

    def keyBlue(self):
        """Bouton bleu = Action selon le mode"""
        if self.max_page > 1 and not self.show_all_mode:
            # Mode pagination: page suivante
            self.nextPage()
        else:
            # Mode normal: afficher toutes les chaînes
            if self.all_channels:
                self.show_all_channels()
            else:
                self["status"].setText("❌ Chargez d'abord les chaînes")

    def keyUp(self):
        """Navigation vers le haut"""
        if self.playing and not self.overlay_visible:
            self.show_overlay()
        
        if self.focus == "bouquet":
            if self.bouquets:
                self.bouquet_index = max(0, self.bouquet_index - 1)
                self["bouquet_list"].moveToIndex(self.bouquet_index)
                self.update_selection_info()
        
        elif self.focus == "channel":
            if self.channels:
                self.channel_index = max(0, self.channel_index - 1)
                self["channel_list"].moveToIndex(self.channel_index)
                self.update_selection_info()
        
        if self.playing:
            self.show_overlay()

    def keyDown(self):
        """Navigation vers le bas"""
        if self.playing and not self.overlay_visible:
            self.show_overlay()
        
        if self.focus == "bouquet":
            if self.bouquets:
                self.bouquet_index = min(len(self.bouquets) - 1, self.bouquet_index + 1)
                self["bouquet_list"].moveToIndex(self.bouquet_index)
                self.update_selection_info()
        
        elif self.focus == "channel":
            if self.channels:
                self.channel_index = min(len(self.channels) - 1, self.channel_index + 1)
                self["channel_list"].moveToIndex(self.channel_index)
                self.update_selection_info()
        
        if self.playing:
            self.show_overlay()

    def keyLeft(self):
        """Navigation vers la gauche = changer de liste"""
        if self.playing and not self.overlay_visible:
            self.show_overlay()
        
        if self.focus == "channel" and self.bouquets:
            self.focus = "bouquet"
            self["info"].setText("Navigation: Bouquets ←")
        elif self.focus == "bouquet" and self.channels:
            # Si on vient d'un bouquet et qu'on a des chaînes, aller aux chaînes
            self.focus = "channel"
            self["info"].setText("Navigation: Chaînes →")
        
        if self.playing:
            self.show_overlay()

    def keyRight(self):
        """Navigation vers la droite = changer de liste"""
        if self.playing and not self.overlay_visible:
            self.show_overlay()
        
        if self.focus == "bouquet" and self.channels:
            self.focus = "channel"
            self["info"].setText("Navigation: Chaînes →")
        elif self.focus == "channel" and self.bouquets:
            self.focus = "bouquet"
            self["info"].setText("Navigation: Bouquets ←")
        
        if self.playing:
            self.show_overlay()

    def prevPage(self):
        """Aller à la page précédente"""
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        
        if self.focus == "channel" and self.current_genre_id:
            if self.current_page > 1:
                self.load_channels(page=self.current_page - 1)
                self["status"].setText(f"Page précédente: {self.current_page}")
            else:
                self["status"].setText("⚠️ Vous êtes déjà sur la première page")
        
        if self.playing:
            self.show_overlay()

    def nextPage(self):
        """Aller à la page suivante"""
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        
        if self.focus == "channel" and self.current_genre_id:
            if self.current_page < self.max_page:
                self.load_channels(page=self.current_page + 1)
                self["status"].setText(f"Page suivante: {self.current_page}")
            else:
                self["status"].setText("⚠️ Vous êtes déjà sur la dernière page")
        
        if self.playing:
            self.show_overlay()

    def prevBouquet(self):
        """Bouquet précédent"""
        if self.bouquets:
            self.bouquet_index = max(0, self.bouquet_index - 1)
            self["bouquet_list"].moveToIndex(self.bouquet_index)
            if self.server_type == 'stalker':
                self.load_channels(self.bouquets[self.bouquet_index]["id"], 1)
            elif self.server_type == 'xtream':
                category_id = self.bouquets[self.bouquet_index].get('category_id')
                self.load_channels(category_id, 1)
            self.update_selection_info()

    def nextBouquet(self):
        """Bouquet suivant"""
        if self.bouquets:
            self.bouquet_index = min(len(self.bouquets) - 1, self.bouquet_index + 1)
            self["bouquet_list"].moveToIndex(self.bouquet_index)
            if self.server_type == 'stalker':
                self.load_channels(self.bouquets[self.bouquet_index]["id"], 1)
            elif self.server_type == 'xtream':
                category_id = self.bouquets[self.bouquet_index].get('category_id')
                self.load_channels(category_id, 1)
            self.update_selection_info()

    def numberKey(self, number):
        """Touche numérique pressée (0-9)"""
        if self.playing and not self.overlay_visible:
            self.show_overlay()
            return
        
        if number == 0:
            # 0 = Aller à la première page
            if self.max_page > 1 and self.current_page != 1:
                self.load_channels(page=1)
                self["status"].setText("⏪ Première page")
        
        elif number == 9:
            # 9 = Aller à la dernière page
            if self.max_page > 1 and self.current_page != self.max_page:
                self.load_channels(page=self.max_page)
                self["status"].setText("⏩ Dernière page")
        
        elif 1 <= number <= 8:
            # 1-8 = Aller à un pourcentage de la liste
            if self.focus == "bouquet" and self.bouquets:
                # Navigation dans les bouquets
                target_index = int((number / 8.0) * len(self.bouquets)) - 1
                if target_index < 0:
                    target_index = 0
                elif target_index >= len(self.bouquets):
                    target_index = len(self.bouquets) - 1
                
                if target_index != self.bouquet_index:
                    self.bouquet_index = target_index
                    self["bouquet_list"].moveToIndex(target_index)
                    self.update_selection_info()
            
            elif self.focus == "channel" and self.channels and self.max_page > 1:
                # Navigation dans les pages
                target_page = int((number / 8.0) * self.max_page)
                if target_page < 1:
                    target_page = 1
                elif target_page > self.max_page:
                    target_page = self.max_page
                
                if target_page != self.current_page:
                    self.load_channels(page=target_page)
                    self["status"].setText(f"↗️ Page {target_page}")

    def show_options_menu(self):
        """Affiche le menu des options"""
        from Screens.ChoiceBox import ChoiceBox
        
        options = [
            ("🔍 Voir toutes les chaînes", "show_all"),
            ("🔄 Recharger toutes les chaînes", "reload_all"),
            ("📝 Voir les logs de debug", "view_logs"),
            ("🧹 Effacer les logs", "clear_logs"),
        ]
        
        self.session.openWithCallback(
            self.options_menu_callback,
            ChoiceBox,
            title="Options",
            list=options
        )

    def options_menu_callback(self, result):
        """Callback pour le menu des options"""
        if result is None:
            return
        
        action = result[1]
        
        if action == "show_all":
            if self.all_channels:
                self.show_all_channels()
            else:
                self["status"].setText("❌ Chargez d'abord les chaînes")
        
        elif action == "reload_all":
            if self.current_genre_id:
                if self.server_type == 'stalker':
                    self.load_all_stalker_channels(self.current_genre_id)
                elif self.server_type == 'xtream':
                    self.load_all_xtream_channels(self.current_genre_id)
        
        elif action == "view_logs":
            self.view_debug_logs()
        
        elif action == "clear_logs":
            self.clear_debug_logs()

    def view_debug_logs(self):
        """Affiche les logs de debug"""
        try:
            if os.path.exists(self.debug_file):
                with open(self.debug_file, "r") as f:
                    logs = f.read()[-2000:]  # Derniers 2000 caractères
                
                from Screens.TextBox import TextBox
                self.session.open(TextBox, text=logs, title="Logs de Debug")
            else:
                self["status"].setText("❌ Aucun log disponible")
        except:
            self["status"].setText("❌ Erreur lecture logs")

    def clear_debug_logs(self):
        """Efface les logs de debug"""
        try:
            open(self.debug_file, "w").close()
            self["status"].setText("✅ Logs effacés")
        except:
            self["status"].setText("❌ Erreur effacement logs")

    # ==================== UTILITAIRES ====================

    def show_error(self, msg):
        """Affiche un message d'erreur (version safe)"""
        # N'ouvrez pas de MessageBox pendant l'initialisation
        # Utilisez plutôt les labels pour afficher les erreurs
        self["status"].setText(f"❌ {msg[:50]}")
        self["info"].setText("Erreur - Voir status")

    def exit(self):
        """Quitte l'écran proprement"""
        if self.playing:
            self.session.nav.stopService()
        self.close()

    # ==================== PROPRIÉTÉS ====================

    @property
    def has_bouquets(self):
        """Vérifie si des bouquets sont disponibles"""
        return len(self.bouquets) > 0

    @property
    def has_channels(self):
        """Vérifie si des chaînes sont disponibles"""
        return len(self.channels) > 0

    @property
    def can_go_prev_page(self):
        """Vérifie si on peut aller à la page précédente"""
        return self.current_page > 1

    @property
    def can_go_next_page(self):
        """Vérifie si on peut aller à la page suivante"""
        return self.current_page < self.max_page