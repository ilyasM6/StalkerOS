from Screens.Screen import Screen
from Components.ActionMap import ActionMap

class SeriesScreen(Screen):
    skin = """
    <screen name="SeriesScreen"
            position="center,center"
            size="1920,1080"
            title="Séries">
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)

        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {
                "cancel": self.close
            }, -1
        )
