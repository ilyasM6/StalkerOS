#!/usr/bin/python
# -*- coding: utf-8 -*-
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.Label import Label
from Screens.MessageBox import MessageBox
from enigma import gRGB

# IMPORTANT: Use absolute imports for other plugin files
try:
    # Try absolute import first (Enigma2 style)
    from Plugins.Extensions.Union_Stream.configuration import ConfigurationScreen
    from Plugins.Extensions.Union_Stream.settings import SettingsScreen
    print("[Union_Stream] Using absolute imports")
except ImportError:
    # Fallback to relative imports
    try:
        from .configuration import ConfigurationScreen
        from .settings import SettingsScreen
        print("[Union_Stream] Using relative imports")
    except ImportError:
        # Last resort: try direct import
        try:
            import sys
            import os
            plugin_dir = os.path.dirname(os.path.abspath(__file__))
            if plugin_dir not in sys.path:
                sys.path.insert(0, plugin_dir)
            from configuration import ConfigurationScreen
            from settings import SettingsScreen
            print("[Union_Stream] Using sys.path import")
        except ImportError as e:
            print(f"[Union_Stream] Import error: {e}")
            # Define fallback classes
            class ConfigurationScreen:
                def __init__(self, session):
                    pass
            class SettingsScreen:
                def __init__(self, session):
                    pass

class Union_StreamMain(Screen):
    """
    Écran principal du plugin Union_Stream IPTV
    Navigation avec 5 boutons verticaux (supprimé Xtream) et 3 boutons horizontaux
    """
    
    skin = """
    <screen name="Union_StreamMain"
            position="center,center"
            size="1920,1080"
            flags="wfNoBorder">

        <!-- Background Image -->
        <ePixmap position="0,0"
                 size="1920,1080"
                 pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Union_Stream/skins/BG_Skins.png"
                 zPosition="-1"/>

        <!-- Title -->
        <widget name="title" position="0,40" size="1920,70"
            zPosition="1" font="Bold;55"
            halign="center" valign="center"
            foregroundColor="#ffffff" transparent="1" />

        <!-- ==================== VERTICAL COLUMN (Left side) ==================== -->
        <!-- Main navigation - 5 boutons avec espacement uniforme (supprimé Xtream) -->
        <widget name="btn_live_vert" position="130,220" size="250,60"
                font="Regular;31" halign="center" valign="center" />

        <widget name="btn_vod_vert" position="130,330" size="250,60"
                font="Regular;31" halign="center" valign="center" />

        <widget name="btn_series_vert" position="130,430" size="250,60"
                font="Regular;31" halign="center" valign="center" />
        
        <!-- RENOMMÉ: Portals -> Servers -->
        <widget name="btn_servers_vert" position="130,530" size="250,60"
                font="Regular;31" halign="center" valign="center" />

        <!-- SUPPRIMÉ: Xtream button -->

        <widget name="btn_configuration_vert" position="130,630" size="250,60"
                font="Regular;31" halign="center" valign="center" />

        <!-- ==================== HORIZONTAL ROW (Middle) ==================== -->
        <!-- Secondary navigation - 3 boutons alignés horizontalement -->
        <widget name="btn_live_horiz" position="630,400" size="250,60"
                font="Regular;28" halign="center" valign="center" transparent="1" />

        <widget name="btn_vod_horiz" position="1050,400" size="250,60"
                font="Regular;28" halign="center" valign="center" transparent="1" />

        <widget name="btn_series_horiz" position="1470,400" size="250,60"
                font="Regular;28" halign="center" valign="center" transparent="1" />

        <!-- Status Information -->
        <widget name="status_info" position="830,520" size="660,100"
                font="Regular;34" halign="center" valign="center"
                foregroundColor="#00ff00" transparent="1" />

        <!-- ==================== EXIT BUTTON ==================== -->
        <widget name="key_red" position="1550,940" size="200,60"
                font="Bold;40" foregroundColor="#ff0000" transparent="1" />
                
        <!-- Server Information -->
        <widget name="server_status" position="830,630" size="660,50"
                font="Regular;27" halign="center" valign="center"
                foregroundColor="#aaaaaa" transparent="1" />
                
        <!-- Player Status -->
        <widget name="player_status" position="850,720" size="660,50"
                font="Regular;30" halign="center" valign="center"
                foregroundColor="#ff9900" transparent="1" />

        <!-- Version Info -->
        <widget name="version_info" position="20,950" size="660,30"
                font="Regular;25" halign="center" valign="center"
                foregroundColor="#888888" transparent="1" />

    </screen>
    """

    def __init__(self, session):
        """
        Initialise l'écran principal
        Args:
            session: Session Enigma2
        """
        Screen.__init__(self, session)

        # ==================== TITRE ====================
        self["title"] = Label("Union_Stream IPTV")
        self["status_info"] = Label("")
        self["server_status"] = Label("")
        self["player_status"] = Label("")
        self["version_info"] = Label("Version 4.0 - Stalker & Xtream")

        # ==================== COLONNE VERTICALE ====================
        # Navigation principale - 5 boutons (supprimé Xtream)
        self["btn_live_vert"] = Button("📺 Live TV")
        self["btn_vod_vert"] = Button("🎬 VOD")
        self["btn_series_vert"] = Button("📺 Series")
        self["btn_servers_vert"] = Button("🌐 Servers")  # RENOMMÉ: Portals -> Servers
        self["btn_configuration_vert"] = Button("⚙️ Configuration")
        
        # ==================== LIGNE HORIZONTALE ====================
        # Navigation secondaire - 3 boutons
        self["btn_live_horiz"] = Button("📺 Live TV")
        self["btn_vod_horiz"] = Button("🎬 VOD")
        self["btn_series_horiz"] = Button("📺 Series")
        
        # ==================== BOUTON DE SORTIE ====================
        self["key_red"] = Button("❌ Exit")

        # ==================== LISTES DE BOUTONS POUR LA NAVIGATION ====================
        
        # Boutons verticaux (5 boutons - supprimé Xtream)
        self.vertical_buttons = [
            self["btn_live_vert"],      # Index 0
            self["btn_vod_vert"],       # Index 1
            self["btn_series_vert"],    # Index 2
            self["btn_servers_vert"],   # Index 3 (RENOMMÉ: Portals -> Servers)
            self["btn_configuration_vert"]  # Index 4
        ]
        
        # Boutons horizontaux (3 boutons)
        self.horizontal_buttons = [
            self["btn_live_horiz"],     # Index 0
            self["btn_vod_horiz"],      # Index 1
            self["btn_series_horiz"]    # Index 2
        ]
        
        # Tous les boutons pour la gestion du focus
        self.all_buttons = self.vertical_buttons + self.horizontal_buttons

        # ==================== SYSTÈME DE NAVIGATION ====================
        self.mode = 'vertical'  # 'vertical' ou 'horizontal'
        self.vertical_index = 0   # 0-4 pour 5 boutons verticaux
        self.horizontal_index = 0 # 0-2 pour 3 boutons horizontaux

        # ==================== ÉTAT DU SERVEUR ET PLAYER ====================
        self.active_server = None
        self.player_available = self.check_player_availability()
        self.check_server_status()

        # IMPORTANT: Attendre le rendu graphique avant d'initialiser le focus
        self.onLayoutFinish.append(self.initFocus)

        # ==================== ACTIONS DE LA TÉLÉCOMMANDE ====================
        self["actions"] = ActionMap(
            ["DirectionActions", "OkCancelActions", "ColorActions"],
            {
                "up": self.keyUp,
                "down": self.keyDown,
                "left": self.keyLeft,
                "right": self.keyRight,
                "ok": self.keyOk,
                "red": self.exit,
                "cancel": self.exit,
            },
            -1  # Priorité
        )

    def initFocus(self):
        """
        Initialise le focus après le rendu de l'interface
        Cette méthode est appelée automatiquement après onLayoutFinish
        """
        print("[Union_Stream] Initializing focus...")
        self.updateFocus()
        
        # Afficher le statut du serveur et du player
        self.update_server_status()
        self.update_player_status()

    def updateFocus(self):
        """
        Met à jour le focus visuel sur le bouton sélectionné
        
        Fonctionnement:
        1. Parcourt tous les boutons
        2. Détermine si le bouton est sélectionné selon le mode actuel
        3. Change les couleurs pour indiquer le focus
        """
        for i, btn in enumerate(self.all_buttons):
            if not btn.instance:
                continue  # Skip si le widget n'est pas encore initialisé
                
            # Déterminer si ce bouton est sélectionné
            is_selected = False
            
            if self.mode == 'vertical' and i < len(self.vertical_buttons):
                # Mode vertical: vérifier si c'est l'index vertical actuel
                is_selected = (i == self.vertical_index)
                
            elif self.mode == 'horizontal' and i >= len(self.vertical_buttons):
                # Mode horizontal: ajuster l'index et vérifier
                adjusted_index = i - len(self.vertical_buttons)
                is_selected = (adjusted_index == self.horizontal_index)
            
            # Appliquer les couleurs selon la sélection
            if is_selected:
                # Bouton sélectionné: fond bleu, texte blanc
                btn.instance.setBackgroundColor(gRGB(90, 141, 238))   # BLUE
                btn.instance.setForegroundColor(gRGB(255, 255, 255)) # WHITE
            else:
                # Bouton non sélectionné: fond gris foncé, texte gris clair
                btn.instance.setBackgroundColor(gRGB(34, 34, 34))    # DARK GRAY
                btn.instance.setForegroundColor(gRGB(200, 200, 200)) # LIGHT GRAY

    def check_player_availability(self):
        """
        Vérifie si le player Enigma2 est disponible
        Returns:
            bool: True si le player est disponible
        """
        try:
            from Screens.InfoBar import InfoBar
            from enigma import eServiceReference
            
            # Tester si les modules sont disponibles
            test_ref = eServiceReference(4097, 0, "http://test.com")
            return True
            
        except ImportError:
            print("[Union_Stream] Player modules not available")
            return False
        except Exception as e:
            print(f"[Union_Stream] Player check error: {e}")
            return False

    def check_server_status(self):
        """Vérifie le statut du serveur actif"""
        try:
            import json
            import os
            
            # Utiliser le nouveau fichier unifié servers.json
            config_file = "/etc/enigma2/Union_Stream/servers.json"
            
            if not os.path.exists(config_file):
                # Essayer l'ancien fichier pour compatibilité
                config_file = "/etc/enigma2/Union_Stream/servers.json"
            
            if not os.path.exists(config_file):
                self["status_info"].setText("⚠️ Pas de configuration")
                return
            
            with open(config_file, 'r') as f:
                data = json.load(f)
            
            # Trouver le serveur actif (nouvelle structure)
            if "servers" in data:
                # Nouveau format unifié
                servers = data.get("servers", [])
                for server in servers:
                    if server.get("active", False):
                        self.active_server = server
                        self["status_info"].setText("✅ Serveur actif")
                        return
            elif "portals" in data:
                # Ancien format (compatibilité)
                portals = data.get("portals", [])
                for portal in portals:
                    if portal.get("active", False):
                        self.active_server = portal
                        self["status_info"].setText("✅ Serveur actif (ancien format)")
                        return
            
            self["status_info"].setText("⚠️ Aucun serveur actif")
            
        except Exception as e:
            print(f"[Union_Stream] Server status error: {e}")
            self["status_info"].setText("❌ Erreur configuration")

    def update_server_status(self):
        """Met à jour l'affichage du statut du serveur"""
        if self.active_server:
            server_name = self.active_server.get('name', 'Serveur inconnu')
            server_host = self.active_server.get('host', 'N/A')
            server_type = self.active_server.get('type', 'stalker')
            
            # Tronquer l'URL si trop longue
            if len(server_host) > 40:
                server_host = server_host[:37] + "..."
            
            type_icon = "📡 " if server_type == "stalker" else "🔗 "
            status_text = f"{type_icon}{server_name} | {server_host}"
            self["server_status"].setText(status_text)
        else:
            self["server_status"].setText("⚠️ Configurez un serveur dans 'Servers'")

    def update_player_status(self):
        """Met à jour l'affichage du statut du player"""
        if self.player_available:
            self["player_status"].setText("✅ Player Enigma2 disponible")
        else:
            self["player_status"].setText("⚠️ Player non disponible - Utilisez player externe")

    # ==================== NAVIGATION VERTICALE ====================
    
    def keyUp(self):
        """
        Navigation vers le haut avec la télécommande
        
        Comportement:
        - En mode vertical: monte d'un bouton
        - En haut de la colonne: passe en mode horizontal
        - En mode horizontal: passe en mode vertical
        """
        if self.mode == 'vertical':
            # Mode vertical: navigation dans la colonne
            if self.vertical_index > 0:
                # Descendre d'un bouton
                self.vertical_index -= 1
                self.updateFocus()
                print(f"[Union_Stream] Up: vertical_index={self.vertical_index}")
            else:
                # Déjà en haut: passer en mode horizontal
                self.mode = 'horizontal'
                self.horizontal_index = 0  # Premier bouton horizontal
                self.updateFocus()
                print(f"[Union_Stream] Up: switched to horizontal mode")
        
        elif self.mode == 'horizontal':
            # Mode horizontal: passer en mode vertical
            self.mode = 'vertical'
            # Si on est sur Live TV/VOD/Series horizontal, aller au même vertical
            if self.horizontal_index < 3:
                self.vertical_index = self.horizontal_index
            else:
                self.vertical_index = 0
            self.updateFocus()
            print(f"[Union_Stream] Up: switched to vertical mode, index={self.vertical_index}")

    def keyDown(self):
        """
        Navigation vers le bas avec la télécommande
        
        Comportement:
        - En mode vertical: descend d'un bouton
        - En bas de la colonne: passe en mode horizontal
        - En mode horizontal: passe en mode vertical
        """
        if self.mode == 'vertical':
            # Mode vertical: navigation dans la colonne
            if self.vertical_index < len(self.vertical_buttons) - 1:
                # Monter d'un bouton
                self.vertical_index += 1
                self.updateFocus()
                print(f"[Union_Stream] Down: vertical_index={self.vertical_index}")
            else:
                # Déjà en bas: passer en mode horizontal
                self.mode = 'horizontal'
                self.horizontal_index = 0  # Premier bouton horizontal
                self.updateFocus()
                print(f"[Union_Stream] Down: switched to horizontal mode")
        
        elif self.mode == 'horizontal':
            # Mode horizontal: passer en mode vertical
            self.mode = 'vertical'
            # Si on est sur Live TV/VOD/Series horizontal, aller au même vertical
            if self.horizontal_index < 3:
                self.vertical_index = self.horizontal_index
            else:
                self.vertical_index = 0
            self.updateFocus()
            print(f"[Union_Stream] Down: switched to vertical mode, index={self.vertical_index}")

    # ==================== NAVIGATION HORIZONTALE ====================
    
    def keyLeft(self):
        """
        Navigation vers la gauche avec la télécommande
        
        Comportement:
        - En mode vertical: passe en mode horizontal (dernier bouton)
        - En mode horizontal: va au bouton précédent
        - Au début: passe en mode vertical
        """
        if self.mode == 'vertical':
            # Mode vertical: passer en mode horizontal (dernier bouton)
            self.mode = 'horizontal'
            self.horizontal_index = len(self.horizontal_buttons) - 1  # Dernier bouton
            self.updateFocus()
            print(f"[Union_Stream] Left: switched to horizontal mode, last button")
        
        elif self.mode == 'horizontal':
            # Mode horizontal: navigation dans la ligne
            if self.horizontal_index > 0:
                # Aller au bouton précédent
                self.horizontal_index -= 1
                self.updateFocus()
                print(f"[Union_Stream] Left: horizontal_index={self.horizontal_index}")
            else:
                # Déjà au début: passer en mode vertical
                self.mode = 'vertical'
                # Si on est sur Live TV/VOD/Series horizontal, aller au même vertical
                if self.horizontal_index < 3:
                    self.vertical_index = self.horizontal_index
                self.updateFocus()
                print(f"[Union_Stream] Left: switched to vertical mode, index={self.vertical_index}")

    def keyRight(self):
        """
        Navigation vers la droite avec la télécommande
        
        Comportement:
        - En mode vertical: passe en mode horizontal (premier bouton)
        - En mode horizontal: va au bouton suivant
        - À la fin: passe en mode vertical
        """
        if self.mode == 'vertical':
            # Mode vertical: passer en mode horizontal (premier bouton)
            self.mode = 'horizontal'
            self.horizontal_index = 0  # Premier bouton
            self.updateFocus()
            print(f"[Union_Stream] Right: switched to horizontal mode, first button")
        
        elif self.mode == 'horizontal':
            # Mode horizontal: navigation dans la ligne
            if self.horizontal_index < len(self.horizontal_buttons) - 1:
                # Aller au bouton suivant
                self.horizontal_index += 1
                self.updateFocus()
                print(f"[Union_Stream] Right: horizontal_index={self.horizontal_index}")
            else:
                # Déjà à la fin: passer en mode vertical
                self.mode = 'vertical'
                # Si on est sur Live TV/VOD/Series horizontal, aller au même vertical
                if self.horizontal_index < 3:
                    self.vertical_index = self.horizontal_index
                self.updateFocus()
                print(f"[Union_Stream] Right: switched to vertical mode, index={self.vertical_index}")

    # ==================== ACTION OK ====================
    
    def keyOk(self):
        """
        Action lorsque OK est pressé sur la télécommande
        
        Déclenche différentes actions selon:
        - Le mode actuel (vertical/horizontal)
        - L'index du bouton sélectionné
        """
        print(f"[Union_Stream] OK pressed: mode={self.mode}, vert_idx={self.vertical_index}, horiz_idx={self.horizontal_index}")
        
        if self.mode == 'vertical':
            # ==================== ACTIONS POUR LA COLONNE VERTICALE ====================
            
            if self.vertical_index == 0:  # Live TV
                print("[Union_Stream] Opening Live TV screen...")
                self.open_live_tv()
                    
            elif self.vertical_index == 1:  # VOD
                print("[Union_Stream] Opening VOD screen...")
                self.open_vod()
                    
            elif self.vertical_index == 2:  # Series
                print("[Union_Stream] Opening Series screen...")
                self.open_series()
            
            elif self.vertical_index == 3:  # Servers (RENOMMÉ de Portals)
                print("[Union_Stream] Opening Servers screen...")
                self.open_servers()  # NOUVELLE MÉTHODE
                    
            elif self.vertical_index == 4:  # Configuration
                print("[Union_Stream] Opening Configuration screen...")
                self.open_configuration()
        
        elif self.mode == 'horizontal':
            # ==================== ACTIONS POUR LA LIGNE HORIZONTALE ====================
            
            if self.horizontal_index == 0:  # Live TV (horizontal)
                print("[Union_Stream] Opening Live TV screen (horizontal)...")
                self.open_live_tv()
                    
            elif self.horizontal_index == 1:  # VOD (horizontal)
                print("[Union_Stream] Opening VOD screen (horizontal)...")
                self.open_vod()
                    
            elif self.horizontal_index == 2:  # Series (horizontal)
                print("[Union_Stream] Opening Series screen (horizontal)...")
                self.open_series()

    # ==================== MÉTHODES D'OUVERTURE DES ÉCRANS ====================
    
    def open_live_tv(self):
        """Ouvre l'écran Live TV avec pagination améliorée"""
        if not self.active_server:
            self.show_error("⚠️ Aucun serveur actif!\n\nVeuillez configurer et activer un serveur dans 'Servers'.")
            return
        
        # Vérifier ServiceApp (optionnel)
        try:
            # Essayer d'importer serviceapp_helper s'il existe
            from .serviceapp_helper import serviceapp_helper
            test_results = serviceapp_helper.test_serviceapp()
            
            if not test_results["serviceapp_available"]:
                self.show_warning(
                    "⚠️ ServiceApp non détecté\n\n"
                    "Pour une meilleure expérience IPTV:\n\n"
                    "1. Menu → Plugins → Télécharger plugins\n"
                    "2. Chercher 'ServiceApp'\n"
                    "3. Installer et redémarrer\n\n"
                    "Vous pouvez continuer mais la lecture sera limitée."
                )
        except ImportError:
            # Le helper n'est pas disponible, continuer quand même
            pass
        
        try:
            # Ouvrir le nouvel écran Live avec pagination
            from .live import LiveScreen
            self.session.open(LiveScreen)
            
        except ImportError as e:
            print(f"[Union_Stream] Error importing LiveScreen: {e}")
            self.show_error("Impossible d'ouvrir Live TV\n\nVérifiez que le fichier live.py existe.")
    
    def open_vod(self):
        """Ouvre l'écran VOD"""
        try:
            from .vod import VodScreen
            self.session.open(VodScreen)
        except ImportError as e:
            print(f"[Union_Stream] Error importing VodScreen: {e}")
            self.show_error("Impossible d'ouvrir VOD")
            
    def open_series(self):
        """Ouvre l'écran Series"""
        try:
            from .series import SeriesScreen
            self.session.open(SeriesScreen)
        except ImportError as e:
            print(f"[Union_Stream] Error importing SeriesScreen: {e}")
            self.show_error("Impossible d'ouvrir Series")
            
    def open_servers(self):
        """
        Ouvre l'écran de gestion des serveurs unifié (Stalker + Xtream)
        Remplace les anciens écrans Portals et Xtream
        """
        try:
            print("[Union_Stream] Opening unified servers management...")
            
            # Essayer plusieurs méthodes d'import
            try:
                # Méthode 1: Import absolu (Enigma2 style)
                from Plugins.Extensions.Union_Stream.servers_list import ServersListScreen
                print("[Union_Stream] Imported via absolute path")
            except ImportError:
                try:
                    # Méthode 2: Import relatif
                    from .servers_list import ServersListScreen
                    print("[Union_Stream] Imported via relative path")
                except ImportError:
                    # Méthode 3: Direct import
                    import sys
                    import os
                    plugin_dir = os.path.dirname(os.path.abspath(__file__))
                    if plugin_dir not in sys.path:
                        sys.path.insert(0, plugin_dir)
                    
                    from servers_list import ServersListScreen
                    print("[Union_Stream] Imported via sys.path")
            
            # Ouvrir l'écran unifié
            self.session.open(ServersListScreen)
            
        except ImportError as e:
            print(f"[Union_Stream] ERROR importing ServersListScreen: {e}")
            
            # Fallback: essayer les anciens écrans pour compatibilité
            try:
                # Essayer d'abord l'ancien écran Portals
                from .portals_list import PortalsListScreen
                print("[Union_Stream] Fallback to old PortalsListScreen")
                self.session.open(PortalsListScreen)
                
            except ImportError:
                try:
                    # Essayer l'écran Xtream comme dernier recours
                    from .xtream_list import XtreamListScreen
                    print("[Union_Stream] Fallback to XtreamListScreen")
                    self.session.open(XtreamListScreen)
                    
                except ImportError as e2:
                    # Afficher un message d'erreur détaillé
                    import glob
                    plugin_dir = os.path.dirname(os.path.abspath(__file__))
                    py_files = glob.glob(os.path.join(plugin_dir, "*.py"))
                    file_names = [os.path.basename(f) for f in py_files]
                    
                    error_msg = f"❌ Impossible d'ouvrir la gestion des serveurs\n\n"
                    error_msg += f"Erreur principal: {str(e)}\n\n"
                    error_msg += f"Fichiers disponibles:\n"
                    
                    for fname in sorted(file_names):
                        error_msg += f"• {fname}\n"
                    
                    error_msg += f"\nLe fichier 'servers_list.py' est requis."
                    
                    self.show_error(error_msg)
            
        except Exception as e:
            print(f"[Union_Stream] ERROR opening servers screen: {e}")
            self.show_error(f"Erreur inattendue: {str(e)[:100]}")
            
    def open_configuration(self):
        """Ouvre l'écran Configuration (mode ajout)"""
        try:
            from .configuration import ConfigurationScreen
            self.session.open(ConfigurationScreen)  # Sans edit_index = mode ajout
        except ImportError as e:
            print(f"[Union_Stream] Error importing ConfigurationScreen: {e}")
            self.show_error("Impossible d'ouvrir Configuration")

    def show_error(self, message):
        """
        Affiche un message d'erreur à l'utilisateur
        Args:
            message (str): Message d'erreur à afficher
        """
        try:
            from Screens.MessageBox import MessageBox
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
        except:
            print(f"[Union_Stream] Error showing message: {message}")

    def show_warning(self, message):
        """
        Affiche un message d'avertissement
        Args:
            message (str): Message d'avertissement à afficher
        """
        try:
            from Screens.MessageBox import MessageBox
            self.session.open(MessageBox, message, MessageBox.TYPE_WARNING)
        except:
            print(f"[Union_Stream] Error showing warning: {message}")

    def exit(self):
        """
        Ferme l'écran proprement
        Appelé par les boutons rouge (red) et annuler (cancel)
        """
        print("[Union_Stream] Exiting Union_Stream...")
        super().close()

    # ==================== NAVIGATION AMÉLIORÉE ====================
    
    def goToVertical(self, index):
        """
        Va directement à un bouton vertical
        Utile pour la navigation programmatique
        
        Args:
            index (int): Index du bouton vertical (0-4)
        """
        if 0 <= index < len(self.vertical_buttons):
            self.mode = 'vertical'
            self.vertical_index = index
            self.updateFocus()
            print(f"[Union_Stream] Went to vertical button {index}")
    
    def goToHorizontal(self, index):
        """
        Va directement à un bouton horizontal
        Utile pour la navigation programmatique
        
        Args:
            index (int): Index du bouton horizontal (0-2)
        """
        if 0 <= index < len(self.horizontal_buttons):
            self.mode = 'horizontal'
            self.horizontal_index = index
            self.updateFocus()
            print(f"[Union_Stream] Went to horizontal button {index}")

    # ==================== MÉTHODES UTILITAIRES ====================
    
    def get_current_selection(self):
        """
        Retourne des informations sur la sélection actuelle
        Utile pour le débogage
        
        Returns:
            dict: Informations sur la sélection
        """
        return {
            'mode': self.mode,
            'vertical_index': self.vertical_index,
            'horizontal_index': self.horizontal_index,
            'vertical_button_count': len(self.vertical_buttons),
            'horizontal_button_count': len(self.horizontal_buttons)
        }
    
    def print_navigation_state(self):
        """
        Affiche l'état de la navigation dans la console
        Utile pour le débogage
        """
        state = self.get_current_selection()
        print(f"[Union_Stream] Navigation State: {state}")