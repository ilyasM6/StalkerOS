#!/bin/bash
# stop_web.sh - Arrête l'interface web Ebro_Stream

PID_FILE="/tmp/ebro_stream_web.pid"

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    
    if ps -p $PID > /dev/null; then
        echo "🛑 Arrêt du serveur web (PID: $PID)..."
        kill $PID
        sleep 2
        
        if ps -p $PID > /dev/null; then
            echo "⚠️  Force l'arrêt..."
            kill -9 $PID
        fi
    fi
    
    rm -f "$PID_FILE"
    echo "✅ Serveur web arrêté"
else
    echo "ℹ️  Aucun serveur web en cours d'exécution"
fi