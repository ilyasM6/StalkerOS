#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
import uuid
from urllib.parse import urlparse, parse_qs

# Configuration
CONFIG_DIR = "/etc/enigma2/Ebro_Stream"
CONFIG_FILE = os.path.join(CONFIG_DIR, "servers.json")
DEFAULT_PORT = 8080

class ServerAPIHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        parsed = urlparse(self.path)
        
        # Route: /api/servers
        if parsed.path == '/api/servers':
            self.get_servers()
        
        # Route: /api/servers/{id}
        elif parsed.path.startswith('/api/servers/'):
            server_id = parsed.path.split('/')[-1]
            self.get_server(server_id)
        
        # Route: / (interface web)
        elif parsed.path == '/' or parsed.path == '/index.html':
            self.serve_web_interface()
        
        else:
            self.send_error(404, "Route non trouvée")
    
    def do_POST(self):
        parsed = urlparse(self.path)
        
        # Route: /api/servers
        if parsed.path == '/api/servers':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            self.add_server(data)
        
        # Route: /api/servers/{id}/toggle
        elif parsed.path.endswith('/toggle'):
            server_id = parsed.path.split('/')[-2]
            self.toggle_server(server_id)
        
        else:
            self.send_error(404, "Route non trouvée")
    
    def do_PUT(self):
        parsed = urlparse(self.path)
        
        # Route: /api/servers/{id}
        if parsed.path.startswith('/api/servers/'):
            server_id = parsed.path.split('/')[-1]
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            self.update_server(server_id, data)
        
        else:
            self.send_error(404, "Route non trouvée")
    
    def do_DELETE(self):
        parsed = urlparse(self.path)
        
        # Route: /api/servers/{id}
        if parsed.path.startswith('/api/servers/'):
            server_id = parsed.path.split('/')[-1]
            self.delete_server(server_id)
        
        else:
            self.send_error(404, "Route non trouvée")
    
    def get_servers(self):
        """Retourne la liste de tous les serveurs"""
        try:
            servers = self.load_servers()
            self.send_json_response(200, servers)
        except Exception as e:
            self.send_json_response(500, {"error": str(e)})
    
    def get_server(self, server_id):
        """Retourne un serveur spécifique"""
        try:
            servers = self.load_servers()
            server = next((s for s in servers if s.get('id') == server_id), None)
            
            if server:
                self.send_json_response(200, server)
            else:
                self.send_json_response(404, {"error": "Serveur non trouvé"})
        except Exception as e:
            self.send_json_response(500, {"error": str(e)})
    
    def add_server(self, data):
        """Ajoute un nouveau serveur"""
        try:
            servers = self.load_servers()
            
            # Générer un ID unique
            data['id'] = str(uuid.uuid4())
            
            # Si le serveur est marqué comme actif, désactiver les autres
            if data.get('active'):
                for server in servers:
                    server['active'] = False
            
            servers.append(data)
            self.save_servers(servers)
            
            self.send_json_response(201, {
                "message": "Serveur ajouté avec succès",
                "id": data['id']
            })
        except Exception as e:
            self.send_json_response(500, {"error": str(e)})
    
    def update_server(self, server_id, data):
        """Met à jour un serveur existant"""
        try:
            servers = self.load_servers()
            
            # Trouver l'index du serveur
            server_index = next((i for i, s in enumerate(servers) if s.get('id') == server_id), -1)
            
            if server_index == -1:
                self.send_json_response(404, {"error": "Serveur non trouvé"})
                return
            
            # Préserver l'ID
            data['id'] = server_id
            
            # Si le serveur est marqué comme actif, désactiver les autres
            if data.get('active'):
                for i, server in enumerate(servers):
                    if i != server_index:
                        server['active'] = False
            
            servers[server_index] = data
            self.save_servers(servers)
            
            self.send_json_response(200, {
                "message": "Serveur mis à jour avec succès"
            })
        except Exception as e:
            self.send_json_response(500, {"error": str(e)})
    
    def delete_server(self, server_id):
        """Supprime un serveur"""
        try:
            servers = self.load_servers()
            
            # Filtrer le serveur à supprimer
            new_servers = [s for s in servers if s.get('id') != server_id]
            
            if len(new_servers) == len(servers):
                self.send_json_response(404, {"error": "Serveur non trouvé"})
                return
            
            self.save_servers(new_servers)
            
            self.send_json_response(200, {
                "message": "Serveur supprimé avec succès"
            })
        except Exception as e:
            self.send_json_response(500, {"error": str(e)})
    
    def toggle_server(self, server_id):
        """Active/désactive un serveur"""
        try:
            servers = self.load_servers()
            
            server_found = False
            for server in servers:
                if server.get('id') == server_id:
                    # Activer ce serveur, désactiver les autres
                    new_state = not server.get('active', False)
                    server['active'] = new_state
                    
                    if new_state:
                        for s in servers:
                            if s.get('id') != server_id:
                                s['active'] = False
                    
                    server_found = True
                    break
            
            if not server_found:
                self.send_json_response(404, {"error": "Serveur non trouvé"})
                return
            
            self.save_servers(servers)
            
            self.send_json_response(200, {
                "message": "État du serveur modifié",
                "active": servers[0].get('active', False) if server_id == servers[0].get('id') else False
            })
        except Exception as e:
            self.send_json_response(500, {"error": str(e)})
    
    def serve_web_interface(self):
        """Sert l'interface web"""
        try:
            with open('index.html', 'rb') as f:
                content = f.read()
            
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except FileNotFoundError:
            self.send_error(404, "Interface web non trouvée")
        except Exception as e:
            self.send_error(500, f"Erreur: {str(e)}")
    
    def load_servers(self):
        """Charge les serveurs depuis le fichier JSON"""
        if not os.path.exists(CONFIG_FILE):
            return []
        
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('servers', [])
        except json.JSONDecodeError:
            return []
    
    def save_servers(self, servers):
        """Sauvegarde les serveurs dans le fichier JSON"""
        # Créer le répertoire s'il n'existe pas
        os.makedirs(CONFIG_DIR, exist_ok=True)
        
        data = {
            "version": "2.0",
            "servers": servers
        }
        
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def send_json_response(self, code, data):
        """Envoie une réponse JSON"""
        response = json.dumps(data, ensure_ascii=False).encode('utf-8')
        
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(response)))
        self.end_headers()
        self.wfile.write(response)
    
    def log_message(self, format, *args):
        """Désactive les logs de requête"""
        pass

def run_server(port=DEFAULT_PORT):
    """Démarre le serveur web"""
    server_address = ('', port)
    httpd = HTTPServer(server_address, ServerAPIHandler)
    
    print(f"🎯 Serveur web démarré sur le port {port}")
    print(f"🌐 Interface accessible à: http://<IP_RECEPTEUR>:{port}")
    print(f"📁 Fichier de configuration: {CONFIG_FILE}")
    print("📱 Utilisez un navigateur web pour configurer vos serveurs")
    print("\n📡 Types de serveurs supportés:")
    print("   • Stalker: URL, MAC")
    print("   • Xtream: Host:Port, Username, Password")
    print("\n🛑 Appuyez sur Ctrl+C pour arrêter")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n\n👋 Arrêt du serveur web")
        httpd.server_close()

if __name__ == '__main__':
    run_server()