#!/bin/sh
# Démarre le serveur web Union_Stream

# Arrêter d'abord si déjà en cours d'exécution
if [ -f /tmp/union_stream_web.pid ]; then
    kill -9 $(cat /tmp/union_stream_web.pid) 2>/dev/null
    rm -f /tmp/union_stream_web.pid
fi

# Démarrer le serveur web Python personnalisé
cd /usr/lib/enigma2/python/Plugins/Extensions/Union_Stream
python3 web_server.py > /tmp/union_stream_web.log 2>&1 &
echo $! > /tmp/union_stream_web.pid

# Attendre un peu pour le démarrage
sleep 2

# Vérifier si le serveur est en cours d'exécution
if netstat -tln | grep -q ":8181 "; then
    echo "✅ Serveur web démarré sur le port 8181"
    exit 0
else
    echo "❌ Échec du démarrage du serveur web"
    echo "📋 Logs: /tmp/union_stream_web.log"
    tail -20 /tmp/union_stream_web.log
    exit 1
fi