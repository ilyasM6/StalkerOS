#!/bin/sh
# Arrête le serveur web Union_Stream

# Arrêter via le PID
if [ -f /tmp/union_stream_web.pid ]; then
    kill -9 $(cat /tmp/union_stream_web.pid) 2>/dev/null
    rm -f /tmp/union_stream_web.pid
fi

# Tuer tout processus python sur le port 8181
pkill -f "web_server.py" 2>/dev/null
pkill -f "http.server 8181" 2>/dev/null

# Vérifier que le port est libéré
sleep 1
if netstat -tln | grep -q ":8181 "; then
    echo "⚠️  Le serveur web semble toujours en cours d'exécution"
    exit 1
else
    echo "✅ Serveur web arrêté"
    exit 0
fi